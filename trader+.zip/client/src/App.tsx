import { Switch, Route } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import DashboardPage from "@/pages/dashboard-page";
import WalletPage from "@/pages/wallet-page";
import TradingPage from "@/pages/trading-page";
import LearnPage from "@/pages/learn-page";
import ProfilePage from "@/pages/profile-page";
import OverviewPage from "@/pages/overview-page";
import P2PPage from "@/pages/p2p-page";
import ICOPage from "@/pages/ico-page";
import FriendsPage from "@/pages/friends-page";
import AboutPage from "@/pages/about-page";
import { ThemeProvider } from "next-themes";

function Router() {
  return (
    <Switch>
      {/* Redirect root path to overview in demo mode */}
      <Route path="/" component={() => {
        window.location.href = "/overview";
        return null;
      }} />
      <Route path="/overview" component={OverviewPage} />
      <Route path="/dashboard" component={DashboardPage} />
      <Route path="/wallet" component={WalletPage} />
      <Route path="/trade" component={TradingPage} />
      <Route path="/learn" component={LearnPage} />
      <Route path="/profile" component={ProfilePage} />
      <Route path="/p2p" component={P2PPage} />
      <Route path="/ico" component={ICOPage} />
      <Route path="/friends" component={FriendsPage} />
      <Route path="/about" component={AboutPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </ThemeProvider>
  );
}

export default App;
