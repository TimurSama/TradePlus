import { useState, useEffect } from "react";
import NewsFeed from "./NewsFeed";
import PriceTable from "./PriceTable";
import TradingChart from "./TradingChart";
import RiskDashboard from "./RiskDashboard";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTrigger, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";

interface DashboardPanelProps {
  fullscreen?: boolean;
}

type PanelType = "news" | "prices" | "chart" | "risk";
type PanelConfig = {
  [key: string]: PanelType;
};

export default function DashboardPanel({ fullscreen = false }: DashboardPanelProps) {
  const [panelConfig, setPanelConfig] = useState<PanelConfig>({
    "panel1": "news",
    "panel2": "prices",
    "panel3": "chart",
    "panel4": "risk"
  });
  
  const [isFullscreen, setIsFullscreen] = useState(fullscreen);

  const renderPanel = (panelId: string, type: PanelType) => {
    switch (type) {
      case "news":
        return <NewsFeed onSettings={() => openSettings(panelId)} />;
      case "prices":
        return <PriceTable onSettings={() => openSettings(panelId)} />;
      case "chart":
        return <TradingChart onSettings={() => openSettings(panelId)} />;
      case "risk":
        return <RiskDashboard onSettings={() => openSettings(panelId)} />;
      default:
        return null;
    }
  };

  const openSettings = (panelId: string) => {
    document.getElementById(`settings-${panelId}`)?.click();
  };

  const updatePanelType = (panelId: string, type: PanelType) => {
    setPanelConfig(prev => ({
      ...prev,
      [panelId]: type
    }));
  };

  return (
    <div className={`${isFullscreen ? "fixed inset-0 z-50 bg-black/90 pt-16 pb-14" : ""}`}>
      <div className={`${isFullscreen ? "h-full overflow-auto p-4" : ""}`}>
        <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800 rounded-2xl">
          <CardContent className={`p-5 ${isFullscreen ? "" : ""}`}>
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-xl font-semibold">Dashboard</h2>
              <Button 
                variant="outline" 
                size="sm"
                className="border-[#FF2D9A] text-[#FF2D9A] hover:bg-[#FF2D9A]/10"
                onClick={() => setIsFullscreen(!isFullscreen)}
              >
                <span className="material-icons text-sm mr-1">
                  {isFullscreen ? "fullscreen_exit" : "fullscreen"}
                </span>
                <span className="text-sm">
                  {isFullscreen ? "Exit" : "Expand"}
                </span>
              </Button>
            </div>
            
            <div className="grid grid-cols-2 gap-3 mb-4">
              {Object.entries(panelConfig).map(([panelId, type], index) => (
                <div key={panelId} className="relative">
                  <Dialog>
                    <DialogTrigger asChild>
                      <button id={`settings-${panelId}`} className="hidden">Settings</button>
                    </DialogTrigger>
                    <DialogContent className="bg-zinc-800 border-gray-700">
                      <DialogTitle>Panel Settings</DialogTitle>
                      <div className="space-y-4">
                        <div>
                          <label className="text-sm font-medium mb-1 block">Panel Type</label>
                          <Select 
                            value={type}
                            onValueChange={(value) => updatePanelType(panelId, value as PanelType)}
                          >
                            <SelectTrigger className="bg-zinc-900">
                              <SelectValue placeholder="Select panel type" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="news">News Feed</SelectItem>
                              <SelectItem value="prices">Price Tables</SelectItem>
                              <SelectItem value="chart">Trading Chart</SelectItem>
                              <SelectItem value="risk">Risk Dashboard</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </DialogContent>
                  </Dialog>
                  
                  {renderPanel(panelId, type)}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
