import { useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';

interface NewsItem {
  id: number;
  title: string;
  summary: string;
  source: string;
  time: string;
}

interface NewsFeedProps {
  onSettings: () => void;
}

export default function NewsFeed({ onSettings }: NewsFeedProps) {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    // Simulate loading news data
    const simulatedNews: NewsItem[] = [
      {
        id: 1,
        title: "Bitcoin breaks $65K resistance",
        summary: "BTC surges past key resistance level as institutional investors increase holdings.",
        source: "CryptoDaily",
        time: "10m ago"
      },
      {
        id: 2,
        title: "Fed meeting impact on markets",
        summary: "Markets respond to Federal Reserve's latest interest rate decision and forward guidance.",
        source: "FinanceNews",
        time: "25m ago"
      },
      {
        id: 3,
        title: "ETH 2.0 update rollout",
        summary: "Ethereum completes another milestone toward full ETH 2.0 implementation.",
        source: "BlockchainReporter",
        time: "45m ago"
      },
      {
        id: 4,
        title: "New regulations impact crypto",
        summary: "Regulatory changes in EU and Asia affect market sentiment and trading volumes.",
        source: "RegulationWatch",
        time: "1h ago"
      }
    ];
    
    setTimeout(() => {
      setNews(simulatedNews);
      setLoading(false);
    }, 800);
  }, []);
  
  return (
    <Card className="h-36 bg-zinc-900/70 border border-[#2DF2C4] rounded-lg">
      <CardContent className="p-3 h-full">
        <div className="flex justify-between items-center mb-2">
          <span className="text-xs font-medium">NEWS FEED</span>
          <button onClick={onSettings} className="text-gray-400 hover:text-white">
            <span className="material-icons text-xs">settings</span>
          </button>
        </div>
        
        {loading ? (
          <div className="grid grid-cols-2 gap-2 overflow-hidden h-24">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="bg-zinc-800/50 rounded-md p-2 text-xs animate-pulse">
                <div className="h-2 w-12 bg-gray-600 rounded mb-1"></div>
                <div className="h-2 w-full bg-gray-600 rounded mb-1"></div>
                <div className="h-2 w-3/4 bg-gray-600 rounded"></div>
              </div>
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-2 overflow-hidden h-24">
            {news.map((item) => (
              <div key={item.id} className="bg-zinc-800/50 rounded-md p-2 text-xs hover:bg-zinc-700/50 transition-colors cursor-pointer">
                <div className="flex justify-between mb-1">
                  <span className="text-xs opacity-70">{item.source}</span>
                  <span className="text-xs opacity-50">{item.time}</span>
                </div>
                <p className="font-medium text-xs mb-1 line-clamp-1">{item.title}</p>
                <p className="text-gray-400 text-xs line-clamp-1">{item.summary}</p>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
