import { useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';

interface PriceData {
  symbol: string;
  price: string;
  change: number;
}

interface PriceTableProps {
  onSettings: () => void;
}

export default function PriceTable({ onSettings }: PriceTableProps) {
  const [prices, setPrices] = useState<PriceData[]>([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    // Simulate loading price data
    const simulatedPrices: PriceData[] = [
      { symbol: "BTC/USDT", price: "64,891.24", change: 1.2 },
      { symbol: "ETH/USDT", price: "3,487.12", change: 0.8 },
      { symbol: "SOL/USDT", price: "129.87", change: -2.1 },
      { symbol: "XRP/USDT", price: "0.5621", change: 1.5 },
      { symbol: "ADA/USDT", price: "0.4521", change: -0.5 },
    ];
    
    setTimeout(() => {
      setPrices(simulatedPrices);
      setLoading(false);
    }, 600);
    
    // Simulate price updates
    const interval = setInterval(() => {
      if (!loading) {
        setPrices(prev => 
          prev.map(item => {
            const changeAmount = (Math.random() * 0.3) - 0.15;
            const priceValue = parseFloat(item.price.replace(',', ''));
            const newPrice = priceValue * (1 + (changeAmount / 100));
            
            return {
              ...item,
              price: newPrice.toFixed(
                Math.min(
                  item.price.includes('.') ? 
                    item.price.split('.')[1].length : 
                    2,
                  4 // Максимальное значение, чтобы избежать ошибки RangeError
                )
              ).replace(/\B(?=(\d{3})+(?!\d))/g, ","),
              change: parseFloat((item.change + changeAmount).toFixed(2))
            };
          })
        );
      }
    }, 5000);
    
    return () => clearInterval(interval);
  }, [loading]);
  
  return (
    <Card className="h-36 bg-zinc-900/70 border border-[#2DF2C4] rounded-lg">
      <CardContent className="p-3 h-full">
        <div className="flex justify-between items-center mb-2">
          <span className="text-xs font-medium">PRICE TABLES</span>
          <button onClick={onSettings} className="text-gray-400 hover:text-white">
            <span className="material-icons text-xs">settings</span>
          </button>
        </div>
        
        {loading ? (
          <div className="space-y-2">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="flex justify-between text-xs mb-1 animate-pulse">
                <div className="h-3 w-20 bg-gray-600 rounded"></div>
                <div className="h-3 w-16 bg-gray-600 rounded"></div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-1">
            {prices.map((item, index) => (
              <div key={index} className="flex justify-between text-xs mb-1 hover:bg-zinc-800/50 px-1 py-0.5 rounded transition-colors cursor-pointer">
                <span>{item.symbol}</span>
                <div className="flex items-center">
                  <span className={item.change >= 0 ? "text-[#2DF2C4]" : "text-[#FF2D9A]"}>
                    ${item.price}
                  </span>
                  <span className={`ml-2 text-[10px] ${item.change >= 0 ? "text-[#2DF2C4]" : "text-[#FF2D9A]"}`}>
                    {item.change >= 0 ? "+" : ""}{item.change}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
