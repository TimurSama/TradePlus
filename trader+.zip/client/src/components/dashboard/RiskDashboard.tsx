import { useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';

interface RiskMetric {
  name: string;
  value: string;
  percentage: number;
  color: string;
}

interface RiskDashboardProps {
  onSettings: () => void;
}

export default function RiskDashboard({ onSettings }: RiskDashboardProps) {
  const [metrics, setMetrics] = useState<RiskMetric[]>([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    // Simulate loading risk metrics
    const simulatedMetrics: RiskMetric[] = [
      { name: "Margin Used", value: "72%", percentage: 72, color: "#FF2D9A" },
      { name: "PnL", value: "+$248.36", percentage: 52, color: "#2DF2C4" },
      { name: "Volatility", value: "Medium", percentage: 45, color: "#2C61FF" },
    ];
    
    setTimeout(() => {
      setMetrics(simulatedMetrics);
      setLoading(false);
    }, 900);
    
    // Simulate occasional updates to the metrics
    const interval = setInterval(() => {
      if (!loading) {
        setMetrics(prev => 
          prev.map(metric => {
            let newPercentage = metric.percentage;
            let newValue = metric.value;
            
            // Randomly update some metrics
            if (Math.random() > 0.6) {
              const change = (Math.random() * 6) - 3; // -3 to +3
              newPercentage = Math.max(5, Math.min(95, metric.percentage + change));
              
              if (metric.name === "Margin Used") {
                newValue = `${Math.round(newPercentage)}%`;
              } else if (metric.name === "PnL") {
                const pnlValue = parseFloat(metric.value.replace('+$', ''));
                const newPnl = pnlValue + (Math.random() * 20 - 10);
                newValue = `${newPnl > 0 ? '+' : ''}$${newPnl.toFixed(2)}`;
              }
            }
            
            return {
              ...metric,
              value: newValue,
              percentage: newPercentage
            };
          })
        );
      }
    }, 10000);
    
    return () => clearInterval(interval);
  }, [loading]);
  
  return (
    <Card className="h-36 bg-zinc-900/70 border border-[#2DF2C4] rounded-lg">
      <CardContent className="p-3 h-full">
        <div className="flex justify-between items-center mb-2">
          <span className="text-xs font-medium">RISK DASHBOARD</span>
          <button onClick={onSettings} className="text-gray-400 hover:text-white">
            <span className="material-icons text-xs">settings</span>
          </button>
        </div>
        
        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="flex justify-between mb-1">
                  <div className="h-3 w-20 bg-gray-600 rounded"></div>
                  <div className="h-3 w-10 bg-gray-600 rounded"></div>
                </div>
                <div className="h-1 bg-zinc-800 rounded-full"></div>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-2">
            {metrics.map((metric, index) => (
              <div key={index} className="text-xs">
                <div className="flex justify-between mb-1">
                  <span>{metric.name}</span>
                  <span className={metric.name === "PnL" && metric.value.includes('+') ? "text-[#2DF2C4]" : ""}>
                    {metric.value}
                  </span>
                </div>
                <Progress 
                  value={metric.percentage} 
                  className="h-1 bg-zinc-800" 
                  style={{ background: metric.color }}
                />
              </div>
            ))}
            
            <div className="text-xs mt-1.5">
              <div className="flex justify-between mb-1">
                <span>Stop-Loss</span>
                <span className="text-[#FF2D9A]">-5.2%</span>
              </div>
              <div className="flex justify-between">
                <span>Take-Profit</span>
                <span className="text-[#2DF2C4]">+12.5%</span>
              </div>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
