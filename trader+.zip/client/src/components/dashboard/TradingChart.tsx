import { useEffect, useState, useRef } from 'react';
import { Card, CardContent } from '@/components/ui/card';

interface TradingChartProps {
  onSettings: () => void;
}

interface ChartDataPoint {
  time: number;
  value: number;
}

export default function TradingChart({ onSettings }: TradingChartProps) {
  const [chartData, setChartData] = useState<ChartDataPoint[]>([]);
  const [loading, setLoading] = useState(true);
  const svgRef = useRef<SVGSVGElement>(null);
  
  useEffect(() => {
    // Generate initial chart data - 20 data points
    const generateChartData = () => {
      const now = Date.now();
      const data: ChartDataPoint[] = [];
      let value = 30000 + Math.random() * 5000;
      
      for (let i = 0; i < 20; i++) {
        value = value + (Math.random() * 400 - 200);
        data.push({
          time: now - (19 - i) * 3600000, // Hourly data points
          value
        });
      }
      
      return data;
    };
    
    setTimeout(() => {
      setChartData(generateChartData());
      setLoading(false);
    }, 700);
    
    // Update chart with new data point every 5 seconds
    const interval = setInterval(() => {
      if (!loading && chartData.length > 0) {
        setChartData(prev => {
          const lastValue = prev[prev.length - 1].value;
          const newValue = lastValue + (Math.random() * 400 - 200);
          
          // Keep only the most recent 20 points
          const newData = [...prev.slice(1), {
            time: Date.now(),
            value: newValue
          }];
          
          return newData;
        });
      }
    }, 5000);
    
    return () => clearInterval(interval);
  }, [loading, chartData.length]);
  
  // Generate SVG path for the chart
  const generatePath = () => {
    if (chartData.length === 0 || !svgRef.current) return '';
    
    const svgWidth = svgRef.current.clientWidth || 100;
    const svgHeight = svgRef.current.clientHeight || 50;
    
    const minValue = Math.min(...chartData.map(d => d.value));
    const maxValue = Math.max(...chartData.map(d => d.value));
    const range = maxValue - minValue;
    
    // Scale to 90% of height to add some padding
    const yScale = (svgHeight * 0.9) / range;
    const xScale = svgWidth / (chartData.length - 1);
    
    return chartData.map((point, i) => {
      const x = i * xScale;
      // Invert y-axis because SVG coordinates grow downward
      const y = svgHeight - ((point.value - minValue) * yScale) - (svgHeight * 0.05);
      return `${i === 0 ? 'M' : 'L'}${x},${y}`;
    }).join(' ');
  };
  
  const generateAreaPath = () => {
    if (chartData.length === 0 || !svgRef.current) return '';
    
    const linePath = generatePath();
    const svgWidth = svgRef.current.clientWidth || 100;
    const svgHeight = svgRef.current.clientHeight || 50;
    
    return `${linePath} L${svgWidth},${svgHeight} L0,${svgHeight} Z`;
  };
  
  return (
    <Card className="h-36 bg-zinc-900/70 border border-[#2DF2C4] rounded-lg">
      <CardContent className="p-3 h-full">
        <div className="flex justify-between items-center mb-2">
          <span className="text-xs font-medium">TRADING CHART</span>
          <button onClick={onSettings} className="text-gray-400 hover:text-white">
            <span className="material-icons text-xs">settings</span>
          </button>
        </div>
        
        <div className="h-24 relative">
          {loading ? (
            <div className="h-full w-full flex items-center justify-center">
              <div className="animate-spin h-5 w-5 border-2 border-[#2DF2C4] rounded-full border-t-transparent"></div>
            </div>
          ) : (
            <svg ref={svgRef} className="w-full h-full" viewBox="0 0 100 50" preserveAspectRatio="none">
              <defs>
                <linearGradient id="chart-gradient" x1="0%" y1="0%" x2="0%" y2="100%">
                  <stop offset="0%" stopColor="#2DF2C4" />
                  <stop offset="100%" stopColor="#2DF2C4" stopOpacity="0" />
                </linearGradient>
              </defs>
              <path 
                className="stroke-[#2DF2C4] stroke-2 fill-none" 
                d={generatePath()}
              />
              <path 
                className="fill-[url(#chart-gradient)] opacity-20" 
                d={generateAreaPath()}
              />
            </svg>
          )}
          
          {!loading && (
            <div className="absolute bottom-1 right-1 text-xs opacity-70">
              ${Math.round(chartData[chartData.length - 1]?.value).toLocaleString()}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
