import { useDemoLogin } from "@/hooks/use-demo-login";
import { ReactNode } from "react";

export function DemoModeWrapper({ children }: { children: ReactNode }) {
  // This component will handle auto-login in demo mode
  useDemoLogin();
  
  return <>{children}</>;
}