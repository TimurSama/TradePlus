import { Link, useLocation } from "wouter";

export default function BottomNavigation() {
  const [location] = useLocation();
  
  const isActive = (path: string) => {
    return location === path;
  };
  
  const activeIconClass = "text-[#FF2D9A]";
  const inactiveIconClass = "";

  return (
    <nav className="fixed bottom-0 left-0 right-0 h-14 flex items-center justify-around border-t border-gray-800 bg-black/70 backdrop-blur-md z-40">
      <Link href="/dashboard">
        <button className="flex flex-col items-center justify-center w-12">
          <span className={`material-icons text-sm ${isActive("/dashboard") ? activeIconClass : inactiveIconClass}`}>dashboard</span>
          <span className="text-xs mt-0.5">Dashboard</span>
        </button>
      </Link>
      
      <Link href="/p2p">
        <button className="flex flex-col items-center justify-center w-12">
          <span className={`material-icons text-sm ${isActive("/p2p") ? activeIconClass : inactiveIconClass}`}>swap_horiz</span>
          <span className="text-xs mt-0.5">P2P</span>
        </button>
      </Link>
      
      <Link href="/trade">
        <button className="flex flex-col items-center justify-center w-12 relative">
          <div className={`absolute -top-3 w-10 h-10 rounded-full bg-zinc-900/80 border ${isActive("/trade") ? "border-[#FF2D9A]" : "border-[#2DF2C4]"} flex items-center justify-center`}>
            <span className={`material-icons ${isActive("/trade") ? "text-[#FF2D9A]" : "text-[#2DF2C4]"}`}>candlestick_chart</span>
          </div>
          <span className="text-xs mt-6">Trade</span>
        </button>
      </Link>
      
      <Link href="/ico">
        <button className="flex flex-col items-center justify-center w-12">
          <span className={`material-icons text-sm ${isActive("/ico") ? activeIconClass : inactiveIconClass}`}>token</span>
          <span className="text-xs mt-0.5">ICO</span>
        </button>
      </Link>
      
      <Link href="/friends">
        <button className="flex flex-col items-center justify-center w-12">
          <span className={`material-icons text-sm ${isActive("/friends") ? activeIconClass : inactiveIconClass}`}>group</span>
          <span className="text-xs mt-0.5">Friends</span>
        </button>
      </Link>
      
      <Link href="/profile">
        <button className="flex flex-col items-center justify-center w-12">
          <span className={`material-icons text-sm ${isActive("/profile") ? activeIconClass : inactiveIconClass}`}>person</span>
          <span className="text-xs mt-0.5">Profile</span>
        </button>
      </Link>
    </nav>
  );
}
