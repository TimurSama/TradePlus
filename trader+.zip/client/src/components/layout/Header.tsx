import { useState } from "react";
import { Link, useLocation } from "wouter";
import { AIAssistant } from "@/components/ui/ai-assistant";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

// Demo mode: we simulate a logged-in user
const demoUser = {
  id: 1,
  username: "demo_trader",
  // Password not needed for frontend display
};

export default function Header() {
  // Always use the demo user in demo mode
  const user = demoUser;
  const logoutMutation = { mutate: () => {} };
  const [isAIOpen, setIsAIOpen] = useState(false);

  return (
    <>
      <header className="fixed top-0 left-0 right-0 z-50 h-16 flex items-center px-4 border-b border-gray-800 bg-black/70 backdrop-blur-md">
        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon" className="mr-4">
              <span className="material-icons">menu</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-[250px] bg-zinc-900/90 backdrop-blur-md">
            <div className="flex flex-col gap-6 py-4">
              <Link href="/overview">
                <Button variant="ghost" className="w-full justify-start">
                  <span className="material-icons mr-2">info</span>
                  Overview
                </Button>
              </Link>
              <Link href="/dashboard">
                <Button variant="ghost" className="w-full justify-start">
                  <span className="material-icons mr-2">dashboard</span>
                  Dashboard
                </Button>
              </Link>
              <Link href="/wallet">
                <Button variant="ghost" className="w-full justify-start">
                  <span className="material-icons mr-2">account_balance_wallet</span>
                  Wallet
                </Button>
              </Link>
              <Link href="/trade">
                <Button variant="ghost" className="w-full justify-start">
                  <span className="material-icons mr-2">candlestick_chart</span>
                  Trade
                </Button>
              </Link>
              <Link href="/learn">
                <Button variant="ghost" className="w-full justify-start">
                  <span className="material-icons mr-2">school</span>
                  Learn
                </Button>
              </Link>
              <Link href="/p2p">
                <Button variant="ghost" className="w-full justify-start">
                  <span className="material-icons mr-2">swap_horiz</span>
                  P2P Trading
                </Button>
              </Link>
              <Link href="/ico">
                <Button variant="ghost" className="w-full justify-start">
                  <span className="material-icons mr-2">token</span>
                  Token Sales
                </Button>
              </Link>
              <Link href="/friends">
                <Button variant="ghost" className="w-full justify-start">
                  <span className="material-icons mr-2">group</span>
                  Friends
                </Button>
              </Link>
              <Link href="/profile">
                <Button variant="ghost" className="w-full justify-start">
                  <span className="material-icons mr-2">person</span>
                  Profile
                </Button>
              </Link>
              <Link href="/about">
                <Button variant="ghost" className="w-full justify-start">
                  <span className="material-icons mr-2">info</span>
                  About
                </Button>
              </Link>
              {user && (
                <Button 
                  variant="destructive" 
                  className="mt-auto"
                  onClick={() => logoutMutation.mutate()}
                >
                  <span className="material-icons mr-2">logout</span>
                  Logout
                </Button>
              )}
            </div>
          </SheetContent>
        </Sheet>
        
        <div className="flex-1 flex justify-center items-center">
          <Link href="/">
            <div className="flex items-center cursor-pointer">
              <div className="relative">
                <span className="text-[#2DF2C4] font-bold text-xl">TRADER</span>
                <div className="absolute -top-1 -right-8 transform rotate-12">
                  <span className="text-[#FF2D9A] font-bold text-xl">+</span>
                  <span className="text-[#2DF2C4] font-bold text-xl">PLUS</span>
                </div>
              </div>
            </div>
          </Link>
        </div>
        
        <div className="flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="icon" 
            className="relative"
            onClick={() => setIsAIOpen(true)}
          >
            <span className="material-icons">smart_toy</span>
            <span className="absolute -top-1 -right-1 w-2 h-2 bg-[#2DF2C4] rounded-full animate-pulse"></span>
          </Button>
          
          {!user ? (
            <Link href="/auth">
              <Button 
                className="flex items-center gap-1 px-3 py-1 rounded-full bg-zinc-900/80 border border-[#2DF2C4] text-sm h-auto"
              >
                <span className="material-icons text-sm">login</span>
                <span>Login</span>
              </Button>
            </Link>
          ) : (
            <Link href="/profile">
              <Button 
                variant="ghost" 
                size="icon"
                className="rounded-full border border-[#2DF2C4] h-8 w-8"
              >
                <span className="material-icons text-sm">person</span>
              </Button>
            </Link>
          )}
        </div>
      </header>
      
      <AIAssistant isOpen={isAIOpen} onClose={() => setIsAIOpen(false)} />
    </>
  );
}
