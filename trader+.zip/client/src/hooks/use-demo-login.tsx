import { useEffect } from 'react';
import { useAuth } from './use-auth';

const DEMO_USER = {
  username: 'demo_user',
  password: 'demo_password'
};

export function useDemoLogin() {
  const { user, isLoading, loginMutation } = useAuth();

  useEffect(() => {
    // Check if we need to log in (only if not already logged in and not currently loading)
    if (!user && !isLoading && !loginMutation.isPending) {
      console.log('Auto-logging in demo user...');
      loginMutation.mutate(DEMO_USER);
    }
  }, [user, isLoading, loginMutation]);

  return { isDemoMode: true };
}