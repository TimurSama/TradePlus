import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import Header from "@/components/layout/Header";
import BottomNavigation from "@/components/layout/BottomNavigation";

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-black bg-[radial-gradient(circle_at_25%_25%,rgba(45,242,196,0.05)_0%,transparent_50%),radial-gradient(circle_at_75%_75%,rgba(255,45,154,0.05)_0%,transparent_50%)]">
      <Header />
      <main className="pt-20 pb-16 px-4">
        <section className="bg-zinc-900/50 backdrop-blur-md rounded-2xl p-6 mb-8 relative overflow-hidden">
          <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-[#2DF2C4] opacity-10 blur-xl"></div>
          <div className="absolute -bottom-10 -left-10 w-40 h-40 rounded-full bg-[#FF2D9A] opacity-10 blur-xl"></div>
          
          <div className="flex items-center mb-4">
            <div className="w-14 h-14 rounded-xl bg-zinc-800 flex items-center justify-center border-2 border-[#2DF2C4] mr-4">
              <span className="material-icons text-[#2DF2C4] text-2xl">trending_up</span>
            </div>
            <div>
              <h1 className="text-2xl font-bold">Trader+PLUS</h1>
              <p className="text-gray-400">Next-Generation Trading Ecosystem</p>
            </div>
          </div>
          
          <p className="text-gray-300 mb-6">
            Trader+PLUS is a comprehensive trading platform designed to empower both novice and experienced traders with advanced analytics, educational resources, and social trading features in a single, unified ecosystem.
          </p>
          
          <div className="flex flex-wrap gap-2 mb-6">
            <Badge className="bg-[#2DF2C4]/20 text-[#2DF2C4] border-0">
              All-in-One Platform
            </Badge>
            <Badge className="bg-[#2DF2C4]/20 text-[#2DF2C4] border-0">
              AI-Powered Analytics
            </Badge>
            <Badge className="bg-[#2DF2C4]/20 text-[#2DF2C4] border-0">
              Educational Hub
            </Badge>
            <Badge className="bg-[#FF2D9A]/20 text-[#FF2D9A] border-0">
              Social Trading
            </Badge>
            <Badge className="bg-[#FF2D9A]/20 text-[#FF2D9A] border-0">
              Risk Management
            </Badge>
          </div>
          
          <div className="grid grid-cols-3 gap-3 mb-4 text-center">
            <div className="bg-zinc-800/50 p-3 rounded-lg">
              <div className="text-2xl font-bold text-[#2DF2C4]">15+</div>
              <div className="text-xs text-gray-400">Markets</div>
            </div>
            <div className="bg-zinc-800/50 p-3 rounded-lg">
              <div className="text-2xl font-bold text-[#2DF2C4]">24/7</div>
              <div className="text-xs text-gray-400">Support</div>
            </div>
            <div className="bg-zinc-800/50 p-3 rounded-lg">
              <div className="text-2xl font-bold text-[#2DF2C4]">100K+</div>
              <div className="text-xs text-gray-400">Users</div>
            </div>
          </div>
        </section>
        
        <Tabs defaultValue="features" className="mb-8">
          <TabsList className="w-full mb-4 bg-zinc-900/50">
            <TabsTrigger value="features" className="flex-1">Key Features</TabsTrigger>
            <TabsTrigger value="mission" className="flex-1">Our Mission</TabsTrigger>
            <TabsTrigger value="team" className="flex-1">Team</TabsTrigger>
          </TabsList>
          
          <TabsContent value="features" className="mt-0">
            <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800 mb-4">
              <CardContent className="p-4">
                <div className="space-y-4">
                  <FeatureItem 
                    icon="analytics"
                    color="#2DF2C4"
                    title="Advanced Market Analysis"
                    description="AI-powered analytics with real-time data visualization, sentiment analysis, and market pattern recognition to identify trading opportunities."
                  />
                  
                  <FeatureItem 
                    icon="school"
                    color="#FF2D9A"
                    title="Comprehensive Learning Platform"
                    description="Structured educational content for all experience levels with interactive tutorials, quizzes, and simulated trading exercises."
                  />
                  
                  <FeatureItem 
                    icon="shield"
                    color="#2DF2C4"
                    title="Risk Management Tools"
                    description="Sophisticated risk assessment and management features including portfolio stress testing, automated stop-loss systems, and exposure analysis."
                  />
                  
                  <FeatureItem 
                    icon="people"
                    color="#FF2D9A"
                    title="Social Trading Network"
                    description="Connect with other traders, share insights, follow successful strategies, and participate in trading competitions within a vibrant community."
                  />
                  
                  <FeatureItem 
                    icon="sync"
                    color="#2DF2C4"
                    title="Multi-Exchange Integration"
                    description="Trade across multiple exchanges from a single interface with unified portfolio view and synchronized order management."
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="mission" className="mt-0">
            <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800 mb-4">
              <CardContent className="p-5">
                <h3 className="text-xl font-semibold mb-4">Our Mission & Vision</h3>
                
                <div className="space-y-6">
                  <div>
                    <h4 className="font-medium text-[#2DF2C4] mb-2">Democratizing Trading Knowledge</h4>
                    <p className="text-gray-400 text-sm">
                      We believe everyone should have access to high-quality financial education and trading tools. Our mission is to level the playing field by providing institutional-grade analytics and educational resources to all traders, regardless of experience level or portfolio size.
                    </p>
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-[#2DF2C4] mb-2">Building a Global Trading Community</h4>
                    <p className="text-gray-400 text-sm">
                      Trading doesn't have to be a solitary activity. We're creating a collaborative ecosystem where traders can learn from each other, share insights, and grow together in a supportive environment that encourages knowledge sharing rather than gatekeeping.
                    </p>
                  </div>
                  
                  <div>
                    <h4 className="font-medium text-[#2DF2C4] mb-2">Advocating for Responsible Trading</h4>
                    <p className="text-gray-400 text-sm">
                      We promote a responsible approach to trading that prioritizes risk management, continuous education, and long-term strategy development over short-term gains. Our platform emphasizes informed decision-making and sustainable trading practices.
                    </p>
                  </div>
                  
                  <div className="pt-2 border-t border-gray-800">
                    <p className="text-sm italic text-center text-gray-400">
                      "Our vision is to become the world's leading all-in-one trading ecosystem, empowering millions of traders to achieve their financial goals through education, technology, and community."
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="team" className="mt-0">
            <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800 mb-4">
              <CardContent className="p-5">
                <h3 className="text-xl font-semibold mb-4">Leadership Team</h3>
                
                <div className="grid grid-cols-2 gap-4 mb-6">
                  <TeamMember 
                    name="Alexandra Chen"
                    role="CEO & Founder"
                    initials="AC"
                    description="Former hedge fund manager with 15+ years in financial markets. Specializes in algorithmic trading systems."
                  />
                  
                  <TeamMember 
                    name="Michael Rodriguez"
                    role="CTO"
                    initials="MR"
                    description="Ex-Google AI researcher with expertise in machine learning applications for financial analysis and prediction."
                  />
                  
                  <TeamMember 
                    name="Sarah Williams"
                    role="Chief Education Officer"
                    initials="SW"
                    description="Award-winning financial educator with a background in designing accessible trading curricula."
                  />
                  
                  <TeamMember 
                    name="David Patel"
                    role="Head of Community"
                    initials="DP"
                    description="Community building expert who previously scaled multiple trading communities with 100K+ members."
                  />
                </div>
                
                <div className="text-center text-sm text-gray-400 mb-4">
                  Backed by a team of 45+ professionals across development, design, education, marketing, and customer support.
                </div>
                
                <div className="flex flex-wrap gap-2 justify-center">
                  <Badge variant="outline" className="bg-zinc-800/50 border-0">YCombinator S22</Badge>
                  <Badge variant="outline" className="bg-zinc-800/50 border-0">Sequoia Backed</Badge>
                  <Badge variant="outline" className="bg-zinc-800/50 border-0">FinTech Award 2023</Badge>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        
        <section className="bg-zinc-900/50 backdrop-blur-md rounded-2xl p-6 mb-8 relative overflow-hidden">
          <div className="text-center mb-5">
            <h2 className="text-xl font-bold mb-2">Join the Trading Revolution</h2>
            <p className="text-gray-400">Experience the next generation of trading technology</p>
          </div>
          
          <div className="flex flex-col gap-3">
            <Button className="w-full py-3 rounded-xl bg-[#2DF2C4] hover:bg-[#2DF2C4]/80 text-black font-medium">
              Get Started Now
            </Button>
            
            <Button className="w-full py-3 rounded-xl bg-zinc-900/70 border border-[#FF2D9A] hover:bg-[#FF2D9A]/10 font-medium">
              Contact Us
            </Button>
          </div>
        </section>
      </main>
      <BottomNavigation />
    </div>
  );
}

interface FeatureItemProps {
  icon: string;
  color: string;
  title: string;
  description: string;
}

function FeatureItem({ icon, color, title, description }: FeatureItemProps) {
  return (
    <div className="flex">
      <div className="w-10 h-10 rounded-lg bg-zinc-800 flex items-center justify-center border border-gray-700 mr-3 flex-shrink-0">
        <span className="material-icons" style={{ color }}>{icon}</span>
      </div>
      <div>
        <h3 className="font-medium mb-1">{title}</h3>
        <p className="text-gray-400 text-sm">{description}</p>
      </div>
    </div>
  );
}

interface TeamMemberProps {
  name: string;
  role: string;
  initials: string;
  description: string;
}

function TeamMember({ name, role, initials, description }: TeamMemberProps) {
  return (
    <div className="flex flex-col items-center">
      <Avatar className="h-16 w-16 mb-2 border-2 border-[#2DF2C4]">
        <AvatarFallback className="bg-zinc-800 text-[#2DF2C4]">
          {initials}
        </AvatarFallback>
      </Avatar>
      <h4 className="font-medium">{name}</h4>
      <div className="text-[#FF2D9A] text-xs mb-1">{role}</div>
      <p className="text-gray-400 text-xs text-center">{description}</p>
    </div>
  );
}