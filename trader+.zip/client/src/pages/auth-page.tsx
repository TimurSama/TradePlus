import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import LoginForm from "@/components/auth/LoginForm";
import RegisterForm from "@/components/auth/RegisterForm";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";

export default function AuthPage() {
  const { user, isLoading } = useAuth();
  const [_, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<string>("login");

  // Redirect to home if already logged in
  useEffect(() => {
    if (user && !isLoading) {
      setLocation("/dashboard");
    }
  }, [user, isLoading, setLocation]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="animate-spin h-8 w-8 border-4 border-[#2DF2C4] rounded-full border-t-transparent"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black bg-[radial-gradient(circle_at_25%_25%,rgba(45,242,196,0.05)_0%,transparent_50%),radial-gradient(circle_at_75%_75%,rgba(255,45,154,0.05)_0%,transparent_50%)]">
      <div className="container mx-auto px-4 py-10 flex flex-col lg:flex-row items-center">
        <div className="w-full lg:w-1/2 mb-8 lg:mb-0 lg:pr-8">
          <div className="text-center lg:text-left mb-8">
            <div className="flex justify-center lg:justify-start mb-4">
              <div className="relative">
                <span className="text-[#2DF2C4] font-bold text-3xl">TRADER</span>
                <div className="absolute -top-2 -right-12 transform rotate-12">
                  <span className="text-[#FF2D9A] font-bold text-3xl">+</span>
                  <span className="text-[#2DF2C4] font-bold text-3xl">PLUS</span>
                </div>
              </div>
            </div>
            <h1 className="text-2xl lg:text-4xl font-bold mb-2">
              Your Professional Trading Experience
            </h1>
            <p className="text-gray-400 mb-6">
              All-in-one platform for crypto, stocks, and futures trading with advanced analytics
            </p>
          </div>

          <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800 rounded-xl mb-6">
            <CardContent className="p-5">
              <div className="flex items-center mb-4">
                <div className="w-10 h-10 rounded-lg bg-zinc-800 flex items-center justify-center border-[#2DF2C4] mr-3">
                  <span className="material-icons text-[#2DF2C4]">trending_up</span>
                </div>
                <div>
                  <h3 className="font-medium">Advanced Market Analysis</h3>
                  <p className="text-sm text-gray-400">Real-time data visualization with AI-powered predictions</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800 rounded-xl mb-6">
            <CardContent className="p-5">
              <div className="flex items-center mb-4">
                <div className="w-10 h-10 rounded-lg bg-zinc-800 flex items-center justify-center border-[#2DF2C4] mr-3">
                  <span className="material-icons text-[#2DF2C4]">sync</span>
                </div>
                <div>
                  <h3 className="font-medium">Multi-Exchange Integration</h3>
                  <p className="text-sm text-gray-400">Seamless trading across all major exchanges</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800 rounded-xl">
            <CardContent className="p-5">
              <div className="flex items-center mb-4">
                <div className="w-10 h-10 rounded-lg bg-zinc-800 flex items-center justify-center border-[#2DF2C4] mr-3">
                  <span className="material-icons text-[#2DF2C4]">shield</span>
                </div>
                <div>
                  <h3 className="font-medium">Advanced Risk Management</h3>
                  <p className="text-sm text-gray-400">Comprehensive risk dashboard with volatility metrics</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="w-full lg:w-1/2">
          <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800 rounded-xl">
            <CardContent className="p-6">
              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid grid-cols-2 mb-6">
                  <TabsTrigger value="login">Login</TabsTrigger>
                  <TabsTrigger value="register">Register</TabsTrigger>
                </TabsList>
                
                <TabsContent value="login" className="mt-0">
                  <div className="mb-4">
                    <h2 className="text-xl font-semibold mb-2">Welcome Back</h2>
                    <p className="text-gray-400 text-sm">Sign in to access your account</p>
                  </div>
                  <LoginForm />
                  <div className="mt-4 text-center">
                    <p className="text-sm text-gray-400">
                      Don't have an account?{" "}
                      <button 
                        className="text-[#2DF2C4] hover:underline" 
                        onClick={() => setActiveTab("register")}
                      >
                        Create one
                      </button>
                    </p>
                  </div>
                </TabsContent>
                
                <TabsContent value="register" className="mt-0">
                  <div className="mb-4">
                    <h2 className="text-xl font-semibold mb-2">Create Account</h2>
                    <p className="text-gray-400 text-sm">Join the next generation of traders</p>
                  </div>
                  <RegisterForm />
                  <div className="mt-4 text-center">
                    <p className="text-sm text-gray-400">
                      Already have an account?{" "}
                      <button 
                        className="text-[#2DF2C4] hover:underline" 
                        onClick={() => setActiveTab("login")}
                      >
                        Sign in
                      </button>
                    </p>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
