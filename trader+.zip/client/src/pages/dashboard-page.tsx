import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Header from "@/components/layout/Header";
import BottomNavigation from "@/components/layout/BottomNavigation";
import DashboardPanel from "@/components/dashboard/DashboardPanel";
import { Link } from "wouter";

// Demo user data
const demoUser = {
  id: 1,
  username: "demo_trader",
};

export default function DashboardPage() {
  // Always use the demo user in demo mode
  const user = demoUser;
  
  return (
    <div className="min-h-screen bg-black bg-[radial-gradient(circle_at_25%_25%,rgba(45,242,196,0.05)_0%,transparent_50%),radial-gradient(circle_at_75%_75%,rgba(255,45,154,0.05)_0%,transparent_50%)]">
      <Header />
      <main className="pt-20 pb-16 px-4">
        <section className="mb-8">
          <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800 rounded-2xl">
            <CardContent className="p-5">
              <div className="flex items-start mb-4">
                <div className="w-12 h-12 bg-zinc-800 rounded-full border border-[#2DF2C4] flex items-center justify-center mr-3">
                  <span className="material-icons text-[#2DF2C4]">person</span>
                </div>
                <div>
                  <h2 className="font-medium">Welcome{user ? `, ${user.username}` : ""}!</h2>
                  <p className="text-gray-400 text-sm">Your portfolio is ready for trading</p>
                </div>
              </div>
              
              <div className="flex gap-3">
                <Link href="/wallet">
                  <Button 
                    className="flex-1 border border-[#FF2D9A] bg-zinc-900/50 hover:bg-[#FF2D9A]/10 text-white"
                  >
                    <span className="material-icons text-sm mr-1">account_balance_wallet</span>
                    <span>Deposit</span>
                  </Button>
                </Link>
                <Link href="/trade">
                  <Button 
                    className="flex-1 border border-[#2DF2C4] bg-zinc-900/50 hover:bg-[#2DF2C4]/10 text-white"
                  >
                    <span className="material-icons text-sm mr-1">candlestick_chart</span>
                    <span>Trade</span>
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </section>
        
        <DashboardPanel />
        
        <section className="mt-8">
          <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800 rounded-2xl">
            <CardContent className="p-5">
              <h2 className="text-lg font-medium mb-3">Market Overview</h2>
              
              <div className="space-y-3">
                <div className="p-3 bg-zinc-800/50 rounded-lg flex justify-between items-center">
                  <div>
                    <p className="font-medium">BTC Dominance</p>
                    <p className="text-sm text-gray-400">Market cap share</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-[#2DF2C4]">53.2%</p>
                    <p className="text-sm text-[#2DF2C4]">+0.8%</p>
                  </div>
                </div>
                
                <div className="p-3 bg-zinc-800/50 rounded-lg flex justify-between items-center">
                  <div>
                    <p className="font-medium">Global Market Cap</p>
                    <p className="text-sm text-gray-400">24h change</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium">$2.67T</p>
                    <p className="text-sm text-[#FF2D9A]">-1.2%</p>
                  </div>
                </div>
                
                <div className="p-3 bg-zinc-800/50 rounded-lg flex justify-between items-center">
                  <div>
                    <p className="font-medium">Fear & Greed Index</p>
                    <p className="text-sm text-gray-400">Market sentiment</p>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-[#2DF2C4]">72</p>
                    <p className="text-sm text-gray-400">Greed</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
      </main>
      <BottomNavigation />
    </div>
  );
}
