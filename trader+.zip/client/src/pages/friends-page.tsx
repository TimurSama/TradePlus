import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import Header from "@/components/layout/Header";
import BottomNavigation from "@/components/layout/BottomNavigation";

interface Friend {
  id: number;
  name: string;
  username: string;
  avatar?: string;
  status: "online" | "offline";
  lastActive?: string;
  tradeCount: number;
  pnl: string;
  isFavorite: boolean;
}

interface FriendRequest {
  id: number;
  name: string;
  username: string;
  avatar?: string;
  mutualFriends: number;
  date: string;
}

export default function FriendsPage() {
  const [friends, setFriends] = useState<Friend[]>([
    {
      id: 1,
      name: "Alex Morgan",
      username: "alex_trader",
      status: "online",
      tradeCount: 156,
      pnl: "+18.2%",
      isFavorite: true
    },
    {
      id: 2,
      name: "Sarah Chen",
      username: "sarah_crypto",
      status: "offline",
      lastActive: "2 hours ago",
      tradeCount: 89,
      pnl: "+24.5%",
      isFavorite: true
    },
    {
      id: 3,
      name: "Michael Williams",
      username: "mike_trader",
      status: "online",
      tradeCount: 243,
      pnl: "-2.8%",
      isFavorite: false
    },
    {
      id: 4,
      name: "Emma Johnson",
      username: "emma_invest",
      status: "offline",
      lastActive: "1 day ago",
      tradeCount: 67,
      pnl: "+9.6%",
      isFavorite: false
    },
    {
      id: 5,
      name: "David Zhang",
      username: "dave_crypto",
      status: "online",
      tradeCount: 201,
      pnl: "+32.1%",
      isFavorite: true
    }
  ]);
  
  const [requests, setRequests] = useState<FriendRequest[]>([
    {
      id: 1,
      name: "Jessica Taylor",
      username: "jess_trader",
      mutualFriends: 3,
      date: "1 day ago"
    },
    {
      id: 2,
      name: "Robert Chen",
      username: "rob_invest",
      mutualFriends: 1,
      date: "3 days ago"
    }
  ]);
  
  const [searchTerm, setSearchTerm] = useState("");
  
  const filteredFriends = searchTerm 
    ? friends.filter(friend => 
        friend.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
        friend.username.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : friends;
  
  const onlineFriends = filteredFriends.filter(friend => friend.status === "online");
  const favoriteFriends = filteredFriends.filter(friend => friend.isFavorite);
  
  return (
    <div className="min-h-screen bg-black bg-[radial-gradient(circle_at_25%_25%,rgba(45,242,196,0.05)_0%,transparent_50%),radial-gradient(circle_at_75%_75%,rgba(255,45,154,0.05)_0%,transparent_50%)]">
      <Header />
      <main className="pt-20 pb-16 px-4">
        <div className="flex justify-between items-center mb-5">
          <h1 className="text-2xl font-bold">Trading Friends</h1>
          <Button size="sm" className="bg-[#2DF2C4] hover:bg-[#2DF2C4]/80 text-black">
            <span className="material-icons text-sm mr-1">person_add</span>
            Add Friend
          </Button>
        </div>
        
        <div className="mb-6">
          <Input
            placeholder="Search friends..."
            className="bg-zinc-800 border-gray-700 mb-4"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          
          {requests.length > 0 && (
            <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800 mb-4">
              <CardContent className="p-4">
                <div className="flex justify-between items-center mb-3">
                  <h3 className="font-medium">Friend Requests</h3>
                  <Badge className="bg-[#FF2D9A]/20 text-[#FF2D9A] border-0">
                    {requests.length} New
                  </Badge>
                </div>
                
                <div className="space-y-3">
                  {requests.map(request => (
                    <div key={request.id} className="flex justify-between items-center">
                      <div className="flex items-center">
                        <Avatar className="h-10 w-10 mr-3">
                          <AvatarFallback className="bg-zinc-700">
                            {request.name.substring(0, 2).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <div className="font-medium">{request.name}</div>
                          <div className="text-xs text-gray-400">
                            @{request.username} • {request.mutualFriends} mutual friends
                          </div>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" className="border-gray-700 hover:bg-zinc-800">
                          Ignore
                        </Button>
                        <Button size="sm" className="bg-[#2DF2C4] hover:bg-[#2DF2C4]/80 text-black">
                          Accept
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
        
        <Tabs defaultValue="all" className="mb-6">
          <TabsList className="mb-4 bg-zinc-900/50 gap-2">
            <TabsTrigger value="all">All ({filteredFriends.length})</TabsTrigger>
            <TabsTrigger value="online">Online ({onlineFriends.length})</TabsTrigger>
            <TabsTrigger value="favorites">Favorites ({favoriteFriends.length})</TabsTrigger>
          </TabsList>
          
          <TabsContent value="all" className="space-y-4 mt-0">
            {filteredFriends.map(friend => (
              <FriendCard key={friend.id} friend={friend} />
            ))}
          </TabsContent>
          
          <TabsContent value="online" className="space-y-4 mt-0">
            {onlineFriends.map(friend => (
              <FriendCard key={friend.id} friend={friend} />
            ))}
          </TabsContent>
          
          <TabsContent value="favorites" className="space-y-4 mt-0">
            {favoriteFriends.map(friend => (
              <FriendCard key={friend.id} friend={friend} />
            ))}
          </TabsContent>
        </Tabs>
        
        <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800 mb-4">
          <CardContent className="p-4">
            <h2 className="font-semibold mb-3 flex items-center">
              <span className="material-icons text-[#2DF2C4] mr-2">groups</span>
              Social Trading Benefits
            </h2>
            
            <ul className="text-sm text-gray-400 space-y-2">
              <li className="flex items-start">
                <span className="material-icons text-[#2DF2C4] text-xs mr-2 mt-1">check_circle</span>
                <span>Learn from successful traders by observing their strategies</span>
              </li>
              <li className="flex items-start">
                <span className="material-icons text-[#2DF2C4] text-xs mr-2 mt-1">check_circle</span>
                <span>Share analysis and market insights with your trading network</span>
              </li>
              <li className="flex items-start">
                <span className="material-icons text-[#2DF2C4] text-xs mr-2 mt-1">check_circle</span>
                <span>Participate in trading competitions with friends for rewards</span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </main>
      <BottomNavigation />
    </div>
  );
}

interface FriendCardProps {
  friend: Friend;
}

function FriendCard({ friend }: FriendCardProps) {
  return (
    <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800 hover:border-[#2DF2C4]/50 transition-colors">
      <CardContent className="p-4">
        <div className="flex justify-between items-start">
          <div className="flex items-center">
            <div className="relative mr-3">
              <Avatar className="h-12 w-12">
                <AvatarFallback className="bg-zinc-700">
                  {friend.name.substring(0, 2).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <div className={`absolute -bottom-1 -right-1 w-3.5 h-3.5 rounded-full border-2 border-zinc-900 ${friend.status === 'online' ? 'bg-[#2DF2C4]' : 'bg-gray-500'}`}></div>
            </div>
            <div>
              <div className="flex items-center">
                <h3 className="font-medium mr-2">{friend.name}</h3>
                {friend.isFavorite && (
                  <span className="material-icons text-[#FF2D9A] text-xs">favorite</span>
                )}
              </div>
              <div className="text-xs text-gray-400">@{friend.username}</div>
              <div className="text-xs text-gray-400">
                {friend.status === "online" ? (
                  <span className="text-[#2DF2C4]">Online</span>
                ) : (
                  <span>Last seen {friend.lastActive}</span>
                )}
              </div>
            </div>
          </div>
          <div className="text-right">
            <div className={`font-medium ${friend.pnl.startsWith('+') ? 'text-[#2DF2C4]' : 'text-[#FF2D9A]'}`}>
              {friend.pnl}
            </div>
            <div className="text-xs text-gray-400">{friend.tradeCount} trades</div>
          </div>
        </div>
        
        <div className="flex gap-2 mt-4">
          <Button className="flex-1 border border-gray-700 bg-zinc-800/50 hover:bg-zinc-800 text-white">
            <span className="material-icons text-sm mr-1">visibility</span>
            <span>View Profile</span>
          </Button>
          <Button className="flex-1 border border-[#2DF2C4] bg-zinc-900/50 hover:bg-[#2DF2C4]/10 text-white">
            <span className="material-icons text-sm mr-1">message</span>
            <span>Message</span>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}