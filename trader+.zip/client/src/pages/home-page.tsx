import { useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import Header from "@/components/layout/Header";
import BottomNavigation from "@/components/layout/BottomNavigation";
import DashboardPanel from "@/components/dashboard/DashboardPanel";

export default function HomePage() {
  const [_, setLocation] = useLocation();
  
  useEffect(() => {
    // Redirect to dashboard for now as home page is the dashboard
    setLocation("/dashboard");
  }, [setLocation]);
  
  return (
    <div className="min-h-screen bg-black">
      <Header />
      <div className="pt-20 pb-16 px-4">
        <div className="w-full h-full flex items-center justify-center">
          <div className="animate-spin h-8 w-8 border-4 border-[#2DF2C4] rounded-full border-t-transparent"></div>
        </div>
      </div>
      <BottomNavigation />
    </div>
  );
}
