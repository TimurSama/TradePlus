import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import Header from "@/components/layout/Header";
import BottomNavigation from "@/components/layout/BottomNavigation";

interface ICOProject {
  id: number;
  name: string;
  ticker: string;
  logo: string;
  category: string[];
  description: string;
  raised: number;
  goal: number;
  price: string;
  endDate: string;
  startsIn?: string;
  website: string;
  stage: "upcoming" | "active" | "completed";
}

export default function ICOPage() {
  const [projects, setProjects] = useState<ICOProject[]>([
    {
      id: 1,
      name: "Vodprom",
      ticker: "VODP",
      logo: "water_drop",
      category: ["Utility", "ESG"],
      description: "Decentralized water management system with transparent supply chains and quality monitoring powered by blockchain technology.",
      raised: 1240000,
      goal: 2500000,
      price: "$0.15",
      endDate: "May 15, 2024",
      website: "vodprom.org",
      stage: "active"
    },
    {
      id: 2,
      name: "Trader+PLUS",
      ticker: "TPL",
      logo: "trending_up",
      category: ["Trading", "Finance"],
      description: "Next-generation trading platform with AI-powered analytics, educational resources, and community trading features.",
      raised: 875000,
      goal: 1500000,
      price: "$0.25",
      endDate: "June 10, 2024",
      website: "traderplus.finance",
      stage: "active"
    },
    {
      id: 3,
      name: "AgroChain",
      ticker: "AGRO",
      logo: "eco",
      category: ["Agriculture", "Supply Chain"],
      description: "Blockchain solution for agricultural supply chains providing farm-to-table traceability and fair farmer compensation.",
      raised: 450000,
      goal: 1000000,
      price: "$0.10",
      endDate: "May 30, 2024",
      website: "agrochain.tech",
      stage: "active"
    },
    {
      id: 4,
      name: "NeuralFi",
      ticker: "NRFI",
      logo: "psychology",
      category: ["AI", "DeFi"],
      description: "AI-powered DeFi protocol that optimizes yield strategies across multiple chains with advanced risk management.",
      raised: 2500000,
      goal: 2500000,
      price: "$0.40",
      endDate: "April 5, 2024",
      website: "neuralfi.network",
      stage: "completed"
    },
    {
      id: 5,
      name: "HealthBloc",
      ticker: "HBLC",
      logo: "healing",
      category: ["Healthcare", "Data"],
      description: "Secure healthcare data exchange platform with patient-controlled access and incentives for medical research.",
      raised: 0,
      goal: 3000000,
      price: "$0.20",
      startsIn: "2 weeks",
      endDate: "July 15, 2024",
      website: "healthbloc.io",
      stage: "upcoming"
    }
  ]);
  
  const getProgressPercent = (raised: number, goal: number) => {
    return Math.min(Math.round((raised / goal) * 100), 100);
  };
  
  return (
    <div className="min-h-screen bg-black bg-[radial-gradient(circle_at_25%_25%,rgba(45,242,196,0.05)_0%,transparent_50%),radial-gradient(circle_at_75%_75%,rgba(255,45,154,0.05)_0%,transparent_50%)]">
      <Header />
      <main className="pt-20 pb-16 px-4">
        <h1 className="text-2xl font-bold mb-5">Token Sales</h1>
        
        <Tabs defaultValue="active" className="mb-6">
          <TabsList className="mb-4 bg-zinc-900/50">
            <TabsTrigger value="active">Active</TabsTrigger>
            <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
            <TabsTrigger value="completed">Completed</TabsTrigger>
          </TabsList>
          
          <TabsContent value="active" className="space-y-4 mt-0">
            {projects.filter(p => p.stage === "active").map(project => (
              <Card key={project.id} className="bg-zinc-900/50 backdrop-blur-md border-gray-800 overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center">
                      <div className="w-10 h-10 rounded-lg bg-zinc-800 flex items-center justify-center border border-[#2DF2C4] mr-3">
                        <span className="material-icons text-[#2DF2C4]">{project.logo}</span>
                      </div>
                      <div>
                        <h3 className="font-medium">{project.name}</h3>
                        <div className="flex items-center">
                          <span className="text-xs text-gray-400 mr-2">{project.ticker}</span>
                          <div className="flex">
                            {project.category.map((cat, idx) => (
                              <Badge key={idx} variant="outline" className="mr-1 text-xs bg-zinc-800/80 border-0">
                                {cat}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-[#2DF2C4]">{project.price}</div>
                      <div className="text-xs text-gray-400">Token Price</div>
                    </div>
                  </div>
                  
                  <p className="text-sm text-gray-400 mb-3">{project.description}</p>
                  
                  <div className="mb-3">
                    <div className="flex justify-between text-sm mb-1">
                      <span>${project.raised.toLocaleString()}</span>
                      <span>${project.goal.toLocaleString()}</span>
                    </div>
                    <Progress 
                      value={getProgressPercent(project.raised, project.goal)} 
                      className="h-2 bg-zinc-800" 
                      style={{ background: "#2DF2C4" }}
                    />
                    <div className="flex justify-between text-xs text-gray-400 mt-1">
                      <span>{getProgressPercent(project.raised, project.goal)}% Raised</span>
                      <span>Ends {project.endDate}</span>
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button className="flex-1 border border-[#2DF2C4] bg-zinc-900/50 hover:bg-[#2DF2C4]/10 text-white">
                          Details
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="bg-zinc-800 border-gray-700">
                        <DialogHeader>
                          <DialogTitle className="flex items-center">
                            <span className="material-icons text-[#2DF2C4] mr-2">{project.logo}</span>
                            {project.name} ({project.ticker})
                          </DialogTitle>
                          <DialogDescription>
                            Token sale details and investment information
                          </DialogDescription>
                        </DialogHeader>
                        <div className="space-y-4">
                          <div>
                            <h4 className="text-sm font-medium mb-1">Project Description</h4>
                            <p className="text-sm text-gray-400">{project.description}</p>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <h4 className="text-xs text-gray-400">Token Price</h4>
                              <p className="font-medium">{project.price}</p>
                            </div>
                            <div>
                              <h4 className="text-xs text-gray-400">End Date</h4>
                              <p className="font-medium">{project.endDate}</p>
                            </div>
                            <div>
                              <h4 className="text-xs text-gray-400">Website</h4>
                              <p className="font-medium">{project.website}</p>
                            </div>
                            <div>
                              <h4 className="text-xs text-gray-400">Raised</h4>
                              <p className="font-medium">${project.raised.toLocaleString()} / ${project.goal.toLocaleString()}</p>
                            </div>
                          </div>
                          
                          <Button className="w-full bg-[#2DF2C4] hover:bg-[#2DF2C4]/80 text-black">
                            Participate in Token Sale
                          </Button>
                        </div>
                      </DialogContent>
                    </Dialog>
                    
                    <Button className="flex-1 bg-[#2DF2C4] hover:bg-[#2DF2C4]/80 text-black font-medium">
                      Invest Now
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>
          
          <TabsContent value="upcoming" className="space-y-4 mt-0">
            {projects.filter(p => p.stage === "upcoming").map(project => (
              <Card key={project.id} className="bg-zinc-900/50 backdrop-blur-md border-gray-800 overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center">
                      <div className="w-10 h-10 rounded-lg bg-zinc-800 flex items-center justify-center border border-[#FF2D9A] mr-3">
                        <span className="material-icons text-[#FF2D9A]">{project.logo}</span>
                      </div>
                      <div>
                        <h3 className="font-medium">{project.name}</h3>
                        <div className="flex items-center">
                          <span className="text-xs text-gray-400 mr-2">{project.ticker}</span>
                          <div className="flex">
                            {project.category.map((cat, idx) => (
                              <Badge key={idx} variant="outline" className="mr-1 text-xs bg-zinc-800/80 border-0">
                                {cat}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-[#FF2D9A]">{project.price}</div>
                      <div className="text-xs text-gray-400">Token Price</div>
                    </div>
                  </div>
                  
                  <p className="text-sm text-gray-400 mb-3">{project.description}</p>
                  
                  <div className="mb-3">
                    <Badge className="bg-[#FF2D9A]/20 text-[#FF2D9A] border-0 mb-2">
                      Starts in {project.startsIn}
                    </Badge>
                    <div className="flex justify-between text-xs text-gray-400">
                      <span>Goal: ${project.goal.toLocaleString()}</span>
                      <span>Ends {project.endDate}</span>
                    </div>
                  </div>
                  
                  <Button className="w-full border border-[#FF2D9A] bg-zinc-900/50 hover:bg-[#FF2D9A]/10 text-white">
                    Set Reminder
                  </Button>
                </CardContent>
              </Card>
            ))}
          </TabsContent>
          
          <TabsContent value="completed" className="space-y-4 mt-0">
            {projects.filter(p => p.stage === "completed").map(project => (
              <Card key={project.id} className="bg-zinc-900/50 backdrop-blur-md border-gray-800 overflow-hidden">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center">
                      <div className="w-10 h-10 rounded-lg bg-zinc-800 flex items-center justify-center border border-gray-600 mr-3">
                        <span className="material-icons text-gray-400">{project.logo}</span>
                      </div>
                      <div>
                        <h3 className="font-medium">{project.name}</h3>
                        <div className="flex items-center">
                          <span className="text-xs text-gray-400 mr-2">{project.ticker}</span>
                          <div className="flex">
                            {project.category.map((cat, idx) => (
                              <Badge key={idx} variant="outline" className="mr-1 text-xs bg-zinc-800/80 border-0">
                                {cat}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold">{project.price}</div>
                      <div className="text-xs text-gray-400">Final Price</div>
                    </div>
                  </div>
                  
                  <div className="mb-3">
                    <Badge className="bg-gray-700/50 text-gray-300 border-0 mb-2">
                      Sale Completed
                    </Badge>
                    <div className="flex justify-between text-xs text-gray-400">
                      <span>Raised: ${project.raised.toLocaleString()}</span>
                      <span>Ended on {project.endDate}</span>
                    </div>
                  </div>
                  
                  <Button className="w-full bg-zinc-800 hover:bg-zinc-700 text-white">
                    View Project
                  </Button>
                </CardContent>
              </Card>
            ))}
          </TabsContent>
        </Tabs>
        
        <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800 mb-6">
          <CardContent className="p-4">
            <h2 className="font-semibold mb-3 flex items-center">
              <span className="material-icons text-[#2DF2C4] mr-2">tips_and_updates</span>
              Why Invest in Token Sales?
            </h2>
            
            <ul className="text-sm text-gray-400 space-y-2">
              <li className="flex items-start">
                <span className="material-icons text-[#2DF2C4] text-xs mr-2 mt-1">check_circle</span>
                <span>Early access to innovative blockchain projects with high growth potential</span>
              </li>
              <li className="flex items-start">
                <span className="material-icons text-[#2DF2C4] text-xs mr-2 mt-1">check_circle</span>
                <span>Favorable token prices before exchange listings and wider market access</span>
              </li>
              <li className="flex items-start">
                <span className="material-icons text-[#2DF2C4] text-xs mr-2 mt-1">check_circle</span>
                <span>Support projects aligned with your values and interests in the blockchain space</span>
              </li>
            </ul>
          </CardContent>
        </Card>
      </main>
      <BottomNavigation />
    </div>
  );
}