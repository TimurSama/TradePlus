import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import Header from "@/components/layout/Header";
import BottomNavigation from "@/components/layout/BottomNavigation";

interface Course {
  id: number;
  title: string;
  description: string;
  level: string;
  progress: number;
  lessons: number;
  duration: string;
  instructor: string;
  image?: string;
}

export default function LearnPage() {
  const [courses, setCourses] = useState<Course[]>([
    {
      id: 1,
      title: "Trading Fundamentals",
      description: "Learn the basics of trading, market analysis and risk management",
      level: "Beginner",
      progress: 65,
      lessons: 12,
      duration: "3 hours",
      instructor: "Alex Morgan"
    },
    {
      id: 2,
      title: "Technical Analysis",
      description: "Master chart patterns, indicators and technical trading strategies",
      level: "Intermediate",
      progress: 20,
      lessons: 18,
      duration: "4.5 hours",
      instructor: "Sarah Chen"
    },
    {
      id: 3,
      title: "Advanced Strategies",
      description: "Advanced trading techniques for experienced traders",
      level: "Advanced",
      progress: 0,
      lessons: 15,
      duration: "5 hours",
      instructor: "Michael Williams"
    }
  ]);
  
  return (
    <div className="min-h-screen bg-black bg-[radial-gradient(circle_at_25%_25%,rgba(45,242,196,0.05)_0%,transparent_50%),radial-gradient(circle_at_75%_75%,rgba(255,45,154,0.05)_0%,transparent_50%)]">
      <Header />
      <main className="pt-20 pb-16 px-4">
        <section className="mb-8">
          <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800 rounded-2xl">
            <CardContent className="p-5">
              <h2 className="text-xl font-semibold mb-4">Learning Hub</h2>
              
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center">
                    <span className="material-icons text-[#2DF2C4] mr-2">school</span>
                    <span className="font-medium">Your Progress</span>
                  </div>
                  <span className="text-sm text-gray-400">28%</span>
                </div>
                <Progress value={28} className="h-1 bg-zinc-800" style={{ background: "#2DF2C4" }} />
              </div>
              
              <div className="grid grid-cols-2 gap-3 mb-4">
                <Card className="bg-zinc-800/50 border-gray-700">
                  <CardContent className="p-3 flex flex-col items-center">
                    <div className="w-8 h-8 rounded-full bg-[#2DF2C4]/20 flex items-center justify-center mb-1">
                      <span className="material-icons text-[#2DF2C4] text-sm">book</span>
                    </div>
                    <span className="text-lg font-bold">3</span>
                    <span className="text-xs text-gray-400">Courses Started</span>
                  </CardContent>
                </Card>
                
                <Card className="bg-zinc-800/50 border-gray-700">
                  <CardContent className="p-3 flex flex-col items-center">
                    <div className="w-8 h-8 rounded-full bg-[#FF2D9A]/20 flex items-center justify-center mb-1">
                      <span className="material-icons text-[#FF2D9A] text-sm">verified</span>
                    </div>
                    <span className="text-lg font-bold">1</span>
                    <span className="text-xs text-gray-400">Certificates</span>
                  </CardContent>
                </Card>
              </div>
              
              <Button 
                className="w-full border border-[#2DF2C4] bg-zinc-900/50 hover:bg-[#2DF2C4]/10 text-white"
              >
                <span className="material-icons text-sm mr-1">play_arrow</span>
                <span>Continue Learning</span>
              </Button>
            </CardContent>
          </Card>
        </section>
        
        <section className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Your Courses</h2>
            <Button 
              variant="ghost" 
              size="sm"
              className="text-[#2DF2C4]"
            >
              View All
            </Button>
          </div>
          
          <div className="space-y-4">
            {courses.map(course => (
              <Card key={course.id} className="bg-zinc-900/50 backdrop-blur-md border-gray-800 hover:border-[#2DF2C4]/50 transition-colors">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-medium">{course.title}</h3>
                    <div className="px-2 py-0.5 bg-zinc-800 rounded-full text-xs text-[#2DF2C4]">
                      {course.level}
                    </div>
                  </div>
                  
                  <p className="text-sm text-gray-400 mb-3">{course.description}</p>
                  
                  <div className="flex justify-between items-center text-xs text-gray-400 mb-3">
                    <div className="flex items-center">
                      <span className="material-icons text-xs mr-1">menu_book</span>
                      <span>{course.lessons} Lessons</span>
                    </div>
                    <div className="flex items-center">
                      <span className="material-icons text-xs mr-1">schedule</span>
                      <span>{course.duration}</span>
                    </div>
                  </div>
                  
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center">
                      <div className="w-5 h-5 rounded-full bg-zinc-700 mr-1"></div>
                      <span className="text-xs">{course.instructor}</span>
                    </div>
                    <span className="text-xs">{course.progress}% Complete</span>
                  </div>
                  
                  <Progress value={course.progress} className="h-1 bg-zinc-800" style={{ background: "#2DF2C4" }} />
                  
                  <div className="flex gap-2 mt-3">
                    {course.progress > 0 ? (
                      <Button className="flex-1 border border-[#FF2D9A] bg-zinc-900/50 hover:bg-[#FF2D9A]/10 text-white">
                        <span className="material-icons text-sm mr-1">play_arrow</span>
                        <span>Continue</span>
                      </Button>
                    ) : (
                      <Button className="flex-1 border border-[#2DF2C4] bg-zinc-900/50 hover:bg-[#2DF2C4]/10 text-white">
                        <span className="material-icons text-sm mr-1">play_arrow</span>
                        <span>Start</span>
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
        
        <section>
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold">Recommended</h2>
            <Button 
              variant="ghost" 
              size="sm"
              className="text-[#2DF2C4]"
            >
              Browse All
            </Button>
          </div>
          
          <div className="grid grid-cols-1 gap-4">
            <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-[#2DF2C4]/20 to-[#FF2D9A]/20 opacity-20"></div>
              <CardContent className="p-4 relative">
                <div className="absolute top-2 right-2 px-2 py-0.5 bg-zinc-800 rounded-full text-xs text-[#FF2D9A]">
                  Hot
                </div>
                
                <h3 className="font-medium mb-1">Algorithmic Trading Basics</h3>
                <p className="text-sm text-gray-400 mb-3">
                  Learn how to create, test and deploy automated trading strategies
                </p>
                
                <div className="flex items-center text-xs text-gray-400 mb-4">
                  <div className="flex items-center mr-3">
                    <span className="material-icons text-xs mr-1">menu_book</span>
                    <span>20 Lessons</span>
                  </div>
                  <div className="flex items-center">
                    <span className="material-icons text-xs mr-1">schedule</span>
                    <span>6 hours</span>
                  </div>
                </div>
                
                <Button className="w-full border border-[#2DF2C4] bg-zinc-900/50 hover:bg-[#2DF2C4]/10 text-white">
                  <span className="material-icons text-sm mr-1">add_circle</span>
                  <span>Add to Library</span>
                </Button>
              </CardContent>
            </Card>
            
            <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-[#2DF2C4]/20 to-[#FF2D9A]/20 opacity-20"></div>
              <CardContent className="p-4 relative">
                <h3 className="font-medium mb-1">Risk Management Mastery</h3>
                <p className="text-sm text-gray-400 mb-3">
                  Advanced techniques to protect your capital and maximize returns
                </p>
                
                <div className="flex items-center text-xs text-gray-400 mb-4">
                  <div className="flex items-center mr-3">
                    <span className="material-icons text-xs mr-1">menu_book</span>
                    <span>15 Lessons</span>
                  </div>
                  <div className="flex items-center">
                    <span className="material-icons text-xs mr-1">schedule</span>
                    <span>4.5 hours</span>
                  </div>
                </div>
                
                <Button className="w-full border border-[#2DF2C4] bg-zinc-900/50 hover:bg-[#2DF2C4]/10 text-white">
                  <span className="material-icons text-sm mr-1">add_circle</span>
                  <span>Add to Library</span>
                </Button>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>
      <BottomNavigation />
    </div>
  );
}
