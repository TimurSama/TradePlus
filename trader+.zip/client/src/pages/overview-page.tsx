import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import Header from "@/components/layout/Header";
import BottomNavigation from "@/components/layout/BottomNavigation";
import { Link } from "wouter";

export default function OverviewPage() {
  return (
    <div className="min-h-screen bg-black bg-[radial-gradient(circle_at_25%_25%,rgba(45,242,196,0.05)_0%,transparent_50%),radial-gradient(circle_at_75%_75%,rgba(255,45,154,0.05)_0%,transparent_50%)]">
      <Header />
      <main className="pt-20 pb-16 px-4">
        {/* Hero Section */}
        <section className="bg-zinc-900/50 backdrop-blur-md rounded-2xl p-6 mb-8 relative overflow-hidden">
          <div className="absolute -top-10 -right-10 w-40 h-40 rounded-full bg-[#2DF2C4] opacity-10 blur-xl"></div>
          <div className="absolute -bottom-10 -left-10 w-40 h-40 rounded-full bg-[#FF2D9A] opacity-10 blur-xl"></div>
          
          <h1 className="text-2xl font-bold mb-2">Революционный Trading Experience</h1>
          <p className="text-gray-400 mb-6">Универсальная платформа для профессиональных и начинающих трейдеров</p>
          
          <div className="relative rounded-xl overflow-hidden h-80 mb-6 bg-zinc-800 group">
            {/* Живая анимированная демонстрация */}
            <div className="absolute inset-0 opacity-80">
              <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent z-10"></div>
              
              {/* Анимированный график */}
              <div className="absolute top-4 left-4 right-4 h-20 bg-zinc-900/70 rounded-lg overflow-hidden p-2">
                <div className="h-full w-full relative">
                  <div className="absolute inset-0 flex items-end">
                    <div className="w-1 h-10 bg-[#2DF2C4]/20 mx-0.5 animate-pulse" style={{animationDelay: '0.1s'}}></div>
                    <div className="w-1 h-14 bg-[#2DF2C4]/20 mx-0.5 animate-pulse" style={{animationDelay: '0.2s'}}></div>
                    <div className="w-1 h-8 bg-[#2DF2C4]/20 mx-0.5 animate-pulse" style={{animationDelay: '0.3s'}}></div>
                    <div className="w-1 h-12 bg-[#2DF2C4]/20 mx-0.5 animate-pulse" style={{animationDelay: '0.4s'}}></div>
                    <div className="w-1 h-6 bg-[#2DF2C4]/20 mx-0.5 animate-pulse" style={{animationDelay: '0.5s'}}></div>
                    <div className="w-1 h-16 bg-[#2DF2C4]/20 mx-0.5 animate-pulse" style={{animationDelay: '0.6s'}}></div>
                    <div className="w-1 h-9 bg-[#2DF2C4]/20 mx-0.5 animate-pulse" style={{animationDelay: '0.7s'}}></div>
                    <div className="w-1 h-11 bg-[#2DF2C4]/20 mx-0.5 animate-pulse" style={{animationDelay: '0.8s'}}></div>
                  </div>
                  <svg className="w-full h-full relative z-10" viewBox="0 0 100 40">
                    <path 
                      className="stroke-[#2DF2C4] stroke-2 fill-none animate-dash" 
                      d="M0,30 L12,25 L20,28 L30,20 L40,22 L50,15 L60,10 L70,18 L80,14 L90,8 L100,5"
                      style={{strokeDasharray: '200', strokeDashoffset: '200'}}
                    />
                  </svg>
                </div>
              </div>
              
              {/* Анимированная таблица цен */}
              <div className="absolute top-28 left-4 w-1/2 bg-zinc-900/70 rounded-lg p-2">
                <div className="flex justify-between text-xs mb-1">
                  <span>BTC/USDT</span>
                  <span className="text-[#2DF2C4] animate-pulse">$64,891.24</span>
                </div>
                <div className="flex justify-between text-xs mb-1">
                  <span>ETH/USDT</span>
                  <span className="text-[#2DF2C4]">$3,487.12</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span>SOL/USDT</span>
                  <span className="text-[#FF2D9A] animate-pulse">$129.87</span>
                </div>
              </div>
              
              {/* Анимированные новости */}
              <div className="absolute top-28 right-4 w-1/3 bg-zinc-900/70 rounded-lg p-2">
                <div className="flex items-center text-xs mb-1">
                  <div className="w-1 h-1 rounded-full bg-[#2DF2C4] mr-1"></div>
                  <div className="animate-marquee whitespace-nowrap">
                    Bitcoin approaches new ATH as institutional demand grows
                  </div>
                </div>
                <div className="flex items-center text-xs">
                  <div className="w-1 h-1 rounded-full bg-[#FF2D9A] mr-1"></div>
                  <div className="animate-marquee whitespace-nowrap" style={{animationDelay: '2s'}}>
                    Ethereum 2.0 upgrade ahead of schedule
                  </div>
                </div>
              </div>
            </div>
            
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black to-transparent p-4 z-20">
              <div className="flex items-center mb-2">
                <span className="w-2 h-2 bg-[#2DF2C4] rounded-full animate-pulse mr-2"></span>
                <span className="text-sm font-medium">Интерактивная демонстрация доступна сейчас</span>
              </div>
              <p className="text-xs text-gray-300 mb-2">
                Исследуйте все возможности Trader+PLUS в режиме реального времени с симулированными данными рынка и учебными материалами.
              </p>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-4 mb-4">
            <Link href="/dashboard">
              <Button className="px-6 py-3 rounded-lg bg-zinc-900/70 border-2 border-[#FF2D9A] hover:bg-[#FF2D9A]/10 text-white font-medium">
                <span className="material-icons mr-2">play_circle</span>
                <span>Попробовать демо-версию</span>
              </Button>
            </Link>
            <Link href="#platform-power">
              <Button className="px-6 py-3 rounded-lg bg-zinc-900/70 border-2 border-[#2DF2C4] hover:bg-[#2DF2C4]/10 text-white font-medium">
                <span className="material-icons mr-2">auto_stories</span>
                <span>Узнать больше</span>
              </Button>
            </Link>
          </div>

          <div className="flex justify-between mb-4">
            <Link href="https://t.me/foxampy">
              <Button className="px-4 py-2 rounded-lg bg-zinc-900/70 hover:bg-zinc-800 text-sm">
                <span className="material-icons mr-1 text-sm">chat</span>
                <span>Связаться с нами</span>
              </Button>
            </Link>
            <Button 
              className="px-4 py-2 rounded-lg bg-zinc-900/70 hover:bg-zinc-800 text-sm flex items-center gap-1"
              onClick={() => {
                const currentLang = document.documentElement.lang || 'en';
                document.documentElement.lang = currentLang === 'en' ? 'ru' : 'en';
              }}
            >
              <span className="material-icons text-sm">translate</span>
              <span>RU / EN</span>
            </Button>
          </div>
        </section>
        
        {/* Value Proposition Section */}
        <section className="mb-8" id="platform-power">
          <h2 className="text-xl font-semibold mb-4 flex items-center">
            <span className="material-icons text-[#2DF2C4] mr-2">star</span>
            Platform Power
          </h2>
          
          <div className="grid grid-cols-1 gap-4">
            <Card className="bg-zinc-900/50 backdrop-blur-md p-4 border-gray-800 hover:border-gray-700 transition-all duration-300 transform hover:-translate-y-1">
              <CardContent className="p-0">
                <div className="flex items-start">
                  <div className="w-10 h-10 rounded-lg bg-zinc-800 flex items-center justify-center border border-[#2DF2C4] mr-3">
                    <span className="material-icons text-[#2DF2C4]">trending_up</span>
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Advanced Market Analysis</h3>
                    <p className="text-gray-400 text-sm">Real-time data visualization with AI-powered predictions and liquidity analysis</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-zinc-900/50 backdrop-blur-md p-4 border-gray-800 hover:border-gray-700 transition-all duration-300 transform hover:-translate-y-1">
              <CardContent className="p-0">
                <div className="flex items-start">
                  <div className="w-10 h-10 rounded-lg bg-zinc-800 flex items-center justify-center border border-[#2DF2C4] mr-3">
                    <span className="material-icons text-[#2DF2C4]">sync</span>
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Multi-Exchange Integration</h3>
                    <p className="text-gray-400 text-sm">Seamless trading across all major exchanges with unified portfolio tracking</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-zinc-900/50 backdrop-blur-md p-4 border-gray-800 hover:border-gray-700 transition-all duration-300 transform hover:-translate-y-1">
              <CardContent className="p-0">
                <div className="flex items-start">
                  <div className="w-10 h-10 rounded-lg bg-zinc-800 flex items-center justify-center border border-[#2DF2C4] mr-3">
                    <span className="material-icons text-[#2DF2C4]">shield</span>
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Advanced Risk Management</h3>
                    <p className="text-gray-400 text-sm">Comprehensive risk dashboard with volatility metrics and stop-loss automation</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-zinc-900/50 backdrop-blur-md p-4 border-gray-800 hover:border-gray-700 transition-all duration-300 transform hover:-translate-y-1">
              <CardContent className="p-0">
                <div className="flex items-start">
                  <div className="w-10 h-10 rounded-lg bg-zinc-800 flex items-center justify-center border border-[#2DF2C4] mr-3">
                    <span className="material-icons text-[#2DF2C4]">school</span>
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Trading Education Hub</h3>
                    <p className="text-gray-400 text-sm">Personalized learning paths with practical exercises and expert mentorship</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
        
        {/* Dashboard Preview Section */}
        <section className="bg-zinc-900/50 backdrop-blur-md rounded-2xl p-5 mb-8">
          <h2 className="text-xl font-semibold mb-4">Powerful Dashboard</h2>
          
          <div className="grid grid-cols-2 gap-3 mb-4">
            {/* News Feed */}
            <div className="bg-zinc-900/70 rounded-lg p-3 h-36 border border-[#2DF2C4]">
              <div className="flex justify-between items-center mb-2">
                <span className="text-xs font-medium">NEWS FEED</span>
                <span className="material-icons text-xs">settings</span>
              </div>
              
              <div className="grid grid-cols-2 gap-2 overflow-hidden h-24">
                <div className="bg-zinc-800/50 rounded-md p-2 text-xs">
                  <div className="h-2 w-12 bg-gray-600 opacity-30 rounded mb-1"></div>
                  <div className="h-2 w-full bg-gray-600 opacity-30 rounded mb-1"></div>
                  <div className="h-2 w-3/4 bg-gray-600 opacity-30 rounded"></div>
                </div>
                <div className="bg-zinc-800/50 rounded-md p-2 text-xs">
                  <div className="h-2 w-12 bg-gray-600 opacity-30 rounded mb-1"></div>
                  <div className="h-2 w-full bg-gray-600 opacity-30 rounded mb-1"></div>
                  <div className="h-2 w-3/4 bg-gray-600 opacity-30 rounded"></div>
                </div>
              </div>
            </div>
            
            {/* Price Tables */}
            <div className="bg-zinc-900/70 rounded-lg p-3 h-36 border border-[#2DF2C4]">
              <div className="flex justify-between items-center mb-2">
                <span className="text-xs font-medium">PRICE TABLES</span>
                <span className="material-icons text-xs">settings</span>
              </div>
              
              <div className="overflow-hidden">
                <div className="flex justify-between text-xs mb-1">
                  <span>BTC/USDT</span>
                  <span className="text-[#2DF2C4]">$64,891.24</span>
                </div>
                <div className="flex justify-between text-xs mb-1">
                  <span>ETH/USDT</span>
                  <span className="text-[#2DF2C4]">$3,487.12</span>
                </div>
                <div className="flex justify-between text-xs mb-1">
                  <span>SOL/USDT</span>
                  <span className="text-[#FF2D9A]">$129.87</span>
                </div>
                <div className="flex justify-between text-xs">
                  <span>XRP/USDT</span>
                  <span className="text-[#2DF2C4]">$0.5621</span>
                </div>
              </div>
            </div>
            
            {/* Trading Charts */}
            <div className="bg-zinc-900/70 rounded-lg p-3 h-36 border border-[#2DF2C4]">
              <div className="flex justify-between items-center mb-2">
                <span className="text-xs font-medium">TRADING CHARTS</span>
                <span className="material-icons text-xs">settings</span>
              </div>
              
              <div className="h-24 relative">
                <svg className="w-full h-full" viewBox="0 0 100 50">
                  <defs>
                    <linearGradient id="chart-gradient" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#2DF2C4" />
                      <stop offset="100%" stopColor="#2DF2C4" stopOpacity="0" />
                    </linearGradient>
                  </defs>
                  <path 
                    className="stroke-[#2DF2C4] stroke-2 fill-none" 
                    d="M0,35 L10,32 L20,34 L30,25 L40,28 L50,20 L60,15 L70,18 L80,12 L90,8 L100,5"
                  />
                  <path 
                    className="fill-[url(#chart-gradient)] opacity-20" 
                    d="M0,35 L10,32 L20,34 L30,25 L40,28 L50,20 L60,15 L70,18 L80,12 L90,8 L100,5 V50 H0 Z"
                  />
                </svg>
              </div>
            </div>
            
            {/* Risk Dashboard */}
            <div className="bg-zinc-900/70 rounded-lg p-3 h-36 border border-[#2DF2C4]">
              <div className="flex justify-between items-center mb-2">
                <span className="text-xs font-medium">RISK DASHBOARD</span>
                <span className="material-icons text-xs">settings</span>
              </div>
              
              <div className="space-y-2">
                <div className="text-xs">
                  <div className="flex justify-between mb-1">
                    <span>Margin Used</span>
                    <span>72%</span>
                  </div>
                  <div className="h-1 bg-zinc-800 rounded-full overflow-hidden">
                    <div className="h-full w-3/4 bg-[#FF2D9A] rounded-full"></div>
                  </div>
                </div>
                
                <div className="text-xs">
                  <div className="flex justify-between mb-1">
                    <span>PnL</span>
                    <span className="text-[#2DF2C4]">+$248.36</span>
                  </div>
                  <div className="h-1 bg-zinc-800 rounded-full overflow-hidden">
                    <div className="h-full w-1/2 bg-[#2DF2C4] rounded-full"></div>
                  </div>
                </div>
                
                <div className="text-xs">
                  <div className="flex justify-between mb-1">
                    <span>Volatility</span>
                    <span>Medium</span>
                  </div>
                  <div className="h-1 bg-zinc-800 rounded-full overflow-hidden">
                    <div className="h-full w-1/2 bg-[#2C61FF] rounded-full"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <Link href="/dashboard">
            <Button className="w-full py-2 rounded-lg bg-zinc-900/70 border border-[#FF2D9A] hover:bg-[#FF2D9A]/10 text-white">
              <span className="material-icons text-sm mr-2">fullscreen</span>
              <span>Open Full Dashboard</span>
            </Button>
          </Link>
        </section>
        
        {/* Roadmap Section */}
        <section className="mb-8">
          <h2 className="text-xl font-semibold mb-4 flex items-center">
            <span className="material-icons text-[#2DF2C4] mr-2">map</span>
            Development Roadmap
          </h2>
          
          <div className="relative pl-6">
            <div className="absolute left-0 top-0 h-full w-0.5 bg-gradient-to-b from-[#2DF2C4] to-[#FF2D9A]"></div>
            
            <div className="mb-5 relative">
              <div className="absolute -left-[25px] w-5 h-5 rounded-full bg-black border-2 border-[#2DF2C4]"></div>
              <div className="bg-zinc-900/50 backdrop-blur-md rounded-xl p-4 border border-gray-800">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[#2DF2C4] font-medium">Q1 2023</span>
                  <Badge className="bg-[#2DF2C4]/20 text-[#2DF2C4] border-0">COMPLETED</Badge>
                </div>
                <h3 className="font-medium mb-1">Core Platform Launch</h3>
                <p className="text-gray-400 text-sm">Basic trading functionality with real-time data from major exchanges, fundamental dashboard components</p>
              </div>
            </div>
            
            <div className="mb-5 relative">
              <div className="absolute -left-[25px] w-5 h-5 rounded-full bg-black border-2 border-[#2DF2C4]"></div>
              <div className="bg-zinc-900/50 backdrop-blur-md rounded-xl p-4 border border-gray-800">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[#2DF2C4] font-medium">Q3 2023</span>
                  <Badge className="bg-[#2DF2C4]/20 text-[#2DF2C4] border-0">COMPLETED</Badge>
                </div>
                <h3 className="font-medium mb-1">Advanced Analytics Integration</h3>
                <p className="text-gray-400 text-sm">AI-powered market predictions, advanced charting tools, and educational materials for users</p>
              </div>
            </div>
            
            <div className="mb-5 relative">
              <div className="absolute -left-[25px] w-5 h-5 rounded-full bg-black border-2 border-[#FF2D9A]"></div>
              <div className="bg-zinc-900/50 backdrop-blur-md rounded-xl p-4 border border-gray-800">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-[#FF2D9A] font-medium">Q1 2024</span>
                  <Badge className="bg-[#FF2D9A]/20 text-[#FF2D9A] border-0">CURRENT</Badge>
                </div>
                <h3 className="font-medium mb-1">Social Trading & Communities</h3>
                <p className="text-gray-400 text-sm">Copy trading features, community challenges, and trader ranking system to build engagement</p>
              </div>
            </div>
            
            <div className="relative">
              <div className="absolute -left-[25px] w-5 h-5 rounded-full bg-black border-2 border-gray-600"></div>
              <div className="bg-zinc-900/50 backdrop-blur-md rounded-xl p-4 border border-gray-800">
                <div className="text-gray-400 font-medium mb-1">Q4 2024</div>
                <h3 className="font-medium mb-1">Institutional-Grade Tools</h3>
                <p className="text-gray-400 text-sm">Advanced risk management, API access for institutional traders, and algorithmic trading capabilities</p>
              </div>
            </div>
          </div>
        </section>
        
        {/* Partnership Value Section */}
        <section className="bg-zinc-900/50 backdrop-blur-md rounded-2xl p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4 flex items-center">
            <span className="material-icons text-[#2DF2C4] mr-2">handshake</span>
            Value for Partners
          </h2>
          
          <div className="mb-6">
            <h3 className="text-lg font-medium mb-3">For Educational Leaders</h3>
            
            <div className="space-y-3">
              <div className="flex items-start">
                <div className="mt-1 mr-3 text-[#2DF2C4]">
                  <span className="material-icons text-sm">check_circle</span>
                </div>
                <div>
                  <h4 className="font-medium text-sm">Exclusive Curriculum Access</h4>
                  <p className="text-gray-400 text-xs">Provide your students with industry-leading trading education and practical tools unavailable elsewhere</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="mt-1 mr-3 text-[#2DF2C4]">
                  <span className="material-icons text-sm">check_circle</span>
                </div>
                <div>
                  <h4 className="font-medium text-sm">Institutional Analytics Dashboard</h4>
                  <p className="text-gray-400 text-xs">Track student progress with comprehensive analytics and performance metrics</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="mt-1 mr-3 text-[#2DF2C4]">
                  <span className="material-icons text-sm">check_circle</span>
                </div>
                <div>
                  <h4 className="font-medium text-sm">Revenue Sharing Model</h4>
                  <p className="text-gray-400 text-xs">Earn commission on student upgrades and continued platform usage after graduation</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mb-6">
            <h3 className="text-lg font-medium mb-3">For Industry Partners</h3>
            
            <div className="space-y-3">
              <div className="flex items-start">
                <div className="mt-1 mr-3 text-[#FF2D9A]">
                  <span className="material-icons text-sm">check_circle</span>
                </div>
                <div>
                  <h4 className="font-medium text-sm">White-Label Solutions</h4>
                  <p className="text-gray-400 text-xs">Customize and rebrand our platform to offer under your organization's name</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="mt-1 mr-3 text-[#FF2D9A]">
                  <span className="material-icons text-sm">check_circle</span>
                </div>
                <div>
                  <h4 className="font-medium text-sm">API Integration</h4>
                  <p className="text-gray-400 text-xs">Seamlessly connect your existing systems with our robust trading infrastructure</p>
                </div>
              </div>
              
              <div className="flex items-start">
                <div className="mt-1 mr-3 text-[#FF2D9A]">
                  <span className="material-icons text-sm">check_circle</span>
                </div>
                <div>
                  <h4 className="font-medium text-sm">Co-Marketing Opportunities</h4>
                  <p className="text-gray-400 text-xs">Joint promotional campaigns and shared visibility across our growing user base</p>
                </div>
              </div>
            </div>
          </div>
          
          <Button className="w-full py-3 rounded-lg bg-zinc-900/70 border border-[#2DF2C4] hover:bg-[#2DF2C4]/10 text-white">
            Request Partnership Information
          </Button>
        </section>
        
        {/* Education Section */}
        <section className="mb-8">
          <h2 className="text-xl font-semibold mb-4 flex items-center">
            <span className="material-icons text-[#2DF2C4] mr-2">school</span>
            Educational Ecosystem
          </h2>
          
          <div className="grid grid-cols-1 gap-4">
            <Card className="bg-zinc-900/50 backdrop-blur-md p-5 border border-[#2DF2C4] overflow-hidden relative hover:border-[#2DF2C4]/70 transition-colors duration-300 transform hover:-translate-y-1">
              <CardContent className="p-0">
                <div className="absolute -right-4 -top-4 w-16 h-16 rounded-full bg-[#2DF2C4] opacity-10"></div>
                
                <h3 className="font-medium mb-3">Comprehensive Learning Modules</h3>
                
                <div className="flex flex-wrap gap-2 mb-4">
                  <Badge variant="outline" className="bg-zinc-800/80 border-0">Beginner</Badge>
                  <Badge variant="outline" className="bg-zinc-800/80 border-0">Intermediate</Badge>
                  <Badge variant="outline" className="bg-zinc-800/80 border-0">Advanced</Badge>
                  <Badge variant="outline" className="bg-zinc-800/80 border-0">Expert</Badge>
                </div>
                
                <p className="text-gray-400 text-sm mb-4">Progressive educational tracks tailored to various trading styles and experience levels, with practical exercises and real-market simulations.</p>
                
                <Progress value={75} className="h-1 bg-zinc-800" />
                <div className="flex justify-between text-xs mt-2">
                  <span>75% of users complete basic training</span>
                  <span>300+ lessons</span>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-zinc-900/50 backdrop-blur-md p-5 border-gray-800 hover:border-[#2DF2C4]/30 transition-colors duration-300 transform hover:-translate-y-1">
              <CardContent className="p-0">
                <h3 className="font-medium mb-2">For Educators and Mentors</h3>
                <p className="text-gray-400 text-sm mb-4">Create custom courses, track student progress, and build your reputation within the Trader+PLUS community.</p>
                
                <div className="flex flex-col sm:flex-row gap-2">
                  <div className="bg-zinc-900/70 rounded-lg p-3 flex-1">
                    <div className="flex items-center mb-2">
                      <span className="material-icons text-[#2DF2C4] mr-2">person</span>
                      <span className="text-sm font-medium">Become an Instructor</span>
                    </div>
                    <p className="text-gray-400 text-xs">Share your expertise and earn from your courses</p>
                  </div>
                  
                  <div className="bg-zinc-900/70 rounded-lg p-3 flex-1">
                    <div className="flex items-center mb-2">
                      <span className="material-icons text-[#FF2D9A] mr-2">groups</span>
                      <span className="text-sm font-medium">Create Trading Communities</span>
                    </div>
                    <p className="text-gray-400 text-xs">Build and manage exclusive trading groups</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
        
        {/* Call To Action */}
        <section className="bg-zinc-900/50 backdrop-blur-md rounded-2xl p-6 mb-8 relative overflow-hidden">
          <div className="absolute -top-20 -right-20 w-60 h-60 rounded-full bg-[#FF2D9A] opacity-5 blur-xl"></div>
          <div className="absolute -bottom-20 -left-20 w-60 h-60 rounded-full bg-[#2DF2C4] opacity-5 blur-xl"></div>
          
          <div className="text-center mb-5">
            <h2 className="text-xl font-bold mb-2">Ready to Transform Your Trading?</h2>
            <p className="text-gray-400">Join the next generation of traders and investors</p>
          </div>
          
          <div className="flex flex-col gap-3 mb-5">
            <Link href="/dashboard">
              <Button className="w-full py-3 rounded-xl bg-zinc-900/70 border border-[#FF2D9A] hover:bg-[#FF2D9A]/10 font-medium">
                Try Demo Now
              </Button>
            </Link>
            
            <Link href="/learn-page">
              <Button className="w-full py-3 rounded-xl bg-zinc-900/70 border border-[#2DF2C4] hover:bg-[#2DF2C4]/10 font-medium">
                Explore Learning Resources
              </Button>
            </Link>
          </div>
          
          <div className="flex items-center justify-center gap-3">
            <div className="flex -space-x-2">
              <div className="w-8 h-8 rounded-full bg-zinc-800 border border-[#2DF2C4]"></div>
              <div className="w-8 h-8 rounded-full bg-zinc-800 border border-[#2DF2C4]"></div>
              <div className="w-8 h-8 rounded-full bg-zinc-800 border border-[#2DF2C4]"></div>
            </div>
            <span className="text-sm text-gray-400">+2,500 traders joined this month</span>
          </div>
        </section>
      </main>
      <BottomNavigation />
    </div>
  );
}
