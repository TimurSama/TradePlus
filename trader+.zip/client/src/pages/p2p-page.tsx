import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/layout/Header";
import BottomNavigation from "@/components/layout/BottomNavigation";

interface P2POffer {
  id: number;
  user: string;
  asset: string;
  price: string;
  payment: string[];
  available: string;
  limit: string;
  completed: number;
  rating: number;
}

export default function P2PPage() {
  const [offers, setOffers] = useState<P2POffer[]>([
    {
      id: 1,
      user: "CryptoTrader24",
      asset: "BTC",
      price: "64,521.35",
      payment: ["Bank Transfer", "PayPal"],
      available: "0.25 BTC",
      limit: "$5,000 - $50,000",
      completed: 217,
      rating: 98
    },
    {
      id: 2,
      user: "BlockchainKing",
      asset: "ETH",
      price: "3,482.21",
      payment: ["Card", "Revolut", "Wise"],
      available: "15.4 ETH",
      limit: "$1,000 - $25,000",
      completed: 412,
      rating: 99
    },
    {
      id: 3,
      user: "Satoshi2023",
      asset: "BTC",
      price: "64,489.12",
      payment: ["Wire Transfer", "Cash Deposit"],
      available: "0.75 BTC",
      limit: "$10,000 - $100,000",
      completed: 98,
      rating: 95
    },
    {
      id: 4,
      user: "LiquidityProvider",
      asset: "USDT",
      price: "1.002",
      payment: ["Bank Transfer", "TransferWise", "Revolut"],
      available: "50,000 USDT",
      limit: "$500 - $50,000",
      completed: 523,
      rating: 100
    },
    {
      id: 5,
      user: "VodpromTrader",
      asset: "ETH",
      price: "3,479.45",
      payment: ["Bank Transfer", "Revolut"],
      available: "25.3 ETH",
      limit: "$2,000 - $20,000",
      completed: 89,
      rating: 97
    }
  ]);
  
  return (
    <div className="min-h-screen bg-black bg-[radial-gradient(circle_at_25%_25%,rgba(45,242,196,0.05)_0%,transparent_50%),radial-gradient(circle_at_75%_75%,rgba(255,45,154,0.05)_0%,transparent_50%)]">
      <Header />
      <main className="pt-20 pb-16 px-4">
        <h1 className="text-2xl font-bold mb-5">P2P Trading</h1>
        
        <Tabs defaultValue="buy" className="mb-6">
          <TabsList className="w-full mb-4 bg-zinc-900/50">
            <TabsTrigger value="buy" className="flex-1">Buy</TabsTrigger>
            <TabsTrigger value="sell" className="flex-1">Sell</TabsTrigger>
          </TabsList>
          
          <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800 mb-6">
            <CardContent className="p-4">
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-4">
                <Select defaultValue="BTC">
                  <SelectTrigger className="bg-zinc-800 border-gray-700">
                    <SelectValue placeholder="Select Asset" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="BTC">BTC</SelectItem>
                    <SelectItem value="ETH">ETH</SelectItem>
                    <SelectItem value="USDT">USDT</SelectItem>
                    <SelectItem value="SOL">SOL</SelectItem>
                    <SelectItem value="XRP">XRP</SelectItem>
                  </SelectContent>
                </Select>
                
                <Select defaultValue="USD">
                  <SelectTrigger className="bg-zinc-800 border-gray-700">
                    <SelectValue placeholder="Select Currency" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="USD">USD</SelectItem>
                    <SelectItem value="EUR">EUR</SelectItem>
                    <SelectItem value="GBP">GBP</SelectItem>
                    <SelectItem value="JPY">JPY</SelectItem>
                  </SelectContent>
                </Select>
                
                <Select defaultValue="all">
                  <SelectTrigger className="bg-zinc-800 border-gray-700">
                    <SelectValue placeholder="Payment Method" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Payment Methods</SelectItem>
                    <SelectItem value="bank">Bank Transfer</SelectItem>
                    <SelectItem value="card">Card</SelectItem>
                    <SelectItem value="paypal">PayPal</SelectItem>
                    <SelectItem value="revolut">Revolut</SelectItem>
                  </SelectContent>
                </Select>
                
                <Button className="bg-[#2DF2C4] hover:bg-[#2DF2C4]/80 text-black font-medium">
                  Search
                </Button>
              </div>
              
              <Input 
                placeholder="Enter amount..."
                className="bg-zinc-800 border-gray-700" 
                value="10,000"
              />
            </CardContent>
          </Card>
          
          <TabsContent value="buy" className="space-y-4 mt-0">
            {offers.map(offer => (
              <Card key={offer.id} className="bg-zinc-900/50 backdrop-blur-md border-gray-800 hover:border-[#2DF2C4]/50 transition-colors">
                <CardContent className="p-4">
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium">{offer.user}</span>
                        <Badge className="bg-[#2DF2C4]/20 text-[#2DF2C4] border-0 text-xs">
                          {offer.rating}% Positive
                        </Badge>
                      </div>
                      <div className="text-xs text-gray-400">{offer.completed} trades completed</div>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold text-[#2DF2C4]">${offer.price}</div>
                      <div className="text-xs text-gray-400">per {offer.asset}</div>
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-3 mb-3 text-sm">
                    <div>
                      <div className="text-gray-400 text-xs mb-1">Payment Methods</div>
                      <div className="flex flex-wrap gap-1">
                        {offer.payment.map((method, idx) => (
                          <Badge key={idx} variant="outline" className="bg-zinc-800/80 border-0 text-xs">
                            {method}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div>
                      <div className="text-gray-400 text-xs mb-1">Available</div>
                      <div className="font-medium">{offer.available}</div>
                      <div className="text-gray-400 text-xs">{offer.limit}</div>
                    </div>
                  </div>
                  
                  <Button className="w-full bg-[#2DF2C4] hover:bg-[#2DF2C4]/80 text-black font-medium">
                    Buy {offer.asset}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </TabsContent>
          
          <TabsContent value="sell" className="space-y-4 mt-0">
            <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800">
              <CardContent className="p-5 text-center">
                <div className="mb-3 text-gray-400">
                  <span className="material-icons text-4xl mb-2">storefront</span>
                  <h3 className="text-lg font-medium">Create a Sell Offer</h3>
                </div>
                <p className="text-gray-400 text-sm mb-4">Set your price and payment preferences to start selling your crypto assets</p>
                <Button className="bg-[#FF2D9A] hover:bg-[#FF2D9A]/80 text-white">
                  Create Offer
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        
        <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800 mb-6">
          <CardContent className="p-4">
            <h2 className="font-semibold mb-3 flex items-center">
              <span className="material-icons text-[#2DF2C4] mr-2">shield</span>
              P2P Trading Security Tips
            </h2>
            
            <ul className="text-sm text-gray-400 space-y-2">
              <li className="flex items-start">
                <span className="material-icons text-[#2DF2C4] text-xs mr-2 mt-1">check_circle</span>
                <span>Always use the platform's escrow service. Never transfer outside of the platform.</span>
              </li>
              <li className="flex items-start">
                <span className="material-icons text-[#2DF2C4] text-xs mr-2 mt-1">check_circle</span>
                <span>Check the trader's reputation and completed trades before proceeding.</span>
              </li>
              <li className="flex items-start">
                <span className="material-icons text-[#2DF2C4] text-xs mr-2 mt-1">check_circle</span>
                <span>Keep all communications within the platform's messaging system.</span>
              </li>
            </ul>
          </CardContent>
        </Card>
        
        <div className="text-center text-sm text-gray-400">
          <p>Trader+PLUS P2P connects buyers and sellers directly. The platform acts as a secure escrow service.</p>
        </div>
      </main>
      <BottomNavigation />
    </div>
  );
}