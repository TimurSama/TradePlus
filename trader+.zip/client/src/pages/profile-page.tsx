import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import Header from "@/components/layout/Header";
import BottomNavigation from "@/components/layout/BottomNavigation";

interface Achievement {
  id: number;
  name: string;
  description: string;
  icon: string;
  obtained: boolean;
  date?: string;
}

// Демо-пользователь для демо-режима
const demoUser = {
  id: 1,
  username: "demo_trader",
};

export default function ProfilePage() {
  // В демо-режиме всегда используем демо-пользователя
  const user = demoUser;
  const logoutMutation = { mutate: () => {} };
  const [achievements, setAchievements] = useState<Achievement[]>([
    {
      id: 1,
      name: "First Trade",
      description: "Complete your first trade",
      icon: "shopping_cart",
      obtained: true,
      date: "2023-12-15"
    },
    {
      id: 2,
      name: "Trading Novice",
      description: "Complete 10 trades",
      icon: "trending_up",
      obtained: true,
      date: "2024-01-20"
    },
    {
      id: 3,
      name: "Quick Study",
      description: "Finish your first course",
      icon: "school",
      obtained: true,
      date: "2024-02-05"
    },
    {
      id: 4,
      name: "Portfolio Builder",
      description: "Have 5 different assets in your portfolio",
      icon: "pie_chart",
      obtained: false
    },
    {
      id: 5,
      name: "Profitable Trader",
      description: "Maintain positive P&L for 30 days straight",
      icon: "payments",
      obtained: false
    }
  ]);
  
  return (
    <div className="min-h-screen bg-black bg-[radial-gradient(circle_at_25%_25%,rgba(45,242,196,0.05)_0%,transparent_50%),radial-gradient(circle_at_75%_75%,rgba(255,45,154,0.05)_0%,transparent_50%)]">
      <Header />
      <main className="pt-20 pb-16 px-4">
        <section className="mb-8">
          <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800 rounded-2xl">
            <CardContent className="p-5">
              <div className="flex flex-col items-center">
                <div className="w-20 h-20 rounded-full bg-zinc-800 border-2 border-[#2DF2C4] flex items-center justify-center mb-3">
                  <span className="material-icons text-[#2DF2C4] text-3xl">person</span>
                </div>
                
                <h2 className="text-xl font-bold mb-1">{user ? user.username : "Guest User"}</h2>
                <div className="flex items-center mb-3">
                  <Badge className="bg-[#2DF2C4]/20 text-[#2DF2C4] border border-[#2DF2C4]/20 mr-2">
                    Intermediate
                  </Badge>
                  <div className="flex items-center text-sm text-gray-400">
                    <span className="material-icons text-[#FF2D9A] text-sm mr-1">favorite</span>
                    <span>Rating: 4.8</span>
                  </div>
                </div>
                
                <div className="grid grid-cols-3 w-full gap-3 mb-4">
                  <div className="bg-zinc-800/50 rounded-lg p-2 text-center">
                    <div className="text-xl font-bold">24</div>
                    <div className="text-xs text-gray-400">Trades</div>
                  </div>
                  <div className="bg-zinc-800/50 rounded-lg p-2 text-center">
                    <div className="text-xl font-bold">3</div>
                    <div className="text-xs text-gray-400">Courses</div>
                  </div>
                  <div className="bg-zinc-800/50 rounded-lg p-2 text-center">
                    <div className="text-xl font-bold">5</div>
                    <div className="text-xs text-gray-400">Badges</div>
                  </div>
                </div>
                
                <div className="flex gap-3 w-full">
                  <Button 
                    className="flex-1 border border-[#2DF2C4] bg-zinc-900/50 hover:bg-[#2DF2C4]/10 text-white"
                  >
                    <span className="material-icons text-sm mr-1">edit</span>
                    <span>Edit Profile</span>
                  </Button>
                  <Button 
                    className="flex-1 border border-[#FF2D9A] bg-zinc-900/50 hover:bg-[#FF2D9A]/10 text-white"
                    onClick={() => logoutMutation.mutate()}
                  >
                    <span className="material-icons text-sm mr-1">logout</span>
                    <span>Logout</span>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
        
        <section className="mb-8">
          <Tabs defaultValue="achievements" className="w-full">
            <TabsList className="grid grid-cols-3 bg-zinc-900/50 border border-gray-800 mb-4">
              <TabsTrigger value="achievements">Achievements</TabsTrigger>
              <TabsTrigger value="stats">Stats</TabsTrigger>
              <TabsTrigger value="history">History</TabsTrigger>
            </TabsList>
            
            <TabsContent value="achievements" className="mt-0">
              <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800">
                <CardContent className="p-4">
                  <div className="space-y-4">
                    {achievements.map(achievement => (
                      <div 
                        key={achievement.id} 
                        className={`p-3 rounded-lg flex items-start gap-3 ${achievement.obtained ? 'bg-zinc-800/70' : 'bg-zinc-800/30'}`}
                      >
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center ${achievement.obtained ? 'bg-[#2DF2C4]/20 text-[#2DF2C4]' : 'bg-zinc-700/50 text-gray-500'}`}>
                          <span className="material-icons">{achievement.icon}</span>
                        </div>
                        
                        <div className="flex-1">
                          <div className="flex justify-between items-start">
                            <h3 className={`font-medium ${achievement.obtained ? '' : 'text-gray-500'}`}>
                              {achievement.name}
                            </h3>
                            {achievement.obtained && (
                              <span className="text-xs text-gray-400">
                                {achievement.date}
                              </span>
                            )}
                          </div>
                          <p className={`text-xs ${achievement.obtained ? 'text-gray-400' : 'text-gray-500'}`}>
                            {achievement.description}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="stats" className="mt-0">
              <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800">
                <CardContent className="p-4">
                  <div className="space-y-4">
                    <div className="p-3 bg-zinc-800/50 rounded-lg">
                      <h3 className="font-medium mb-2">Trading Performance</h3>
                      
                      <div className="space-y-2">
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-gray-400">Win Rate</span>
                            <span>62%</span>
                          </div>
                          <div className="h-1 bg-zinc-700 rounded-full overflow-hidden">
                            <div className="h-full w-[62%] bg-[#2DF2C4] rounded-full"></div>
                          </div>
                        </div>
                        
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-gray-400">Avg. Profit</span>
                            <span className="text-[#2DF2C4]">+3.2%</span>
                          </div>
                          <div className="h-1 bg-zinc-700 rounded-full overflow-hidden">
                            <div className="h-full w-[75%] bg-[#2DF2C4] rounded-full"></div>
                          </div>
                        </div>
                        
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-gray-400">Avg. Loss</span>
                            <span className="text-[#FF2D9A]">-1.8%</span>
                          </div>
                          <div className="h-1 bg-zinc-700 rounded-full overflow-hidden">
                            <div className="h-full w-[42%] bg-[#FF2D9A] rounded-full"></div>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="p-3 bg-zinc-800/50 rounded-lg">
                      <h3 className="font-medium mb-2">Learning Progress</h3>
                      
                      <div className="space-y-2">
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-gray-400">Courses Completed</span>
                            <span>1/3</span>
                          </div>
                          <div className="h-1 bg-zinc-700 rounded-full overflow-hidden">
                            <div className="h-full w-[33%] bg-[#2DF2C4] rounded-full"></div>
                          </div>
                        </div>
                        
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-gray-400">Quizzes Passed</span>
                            <span>8/12</span>
                          </div>
                          <div className="h-1 bg-zinc-700 rounded-full overflow-hidden">
                            <div className="h-full w-[66%] bg-[#2DF2C4] rounded-full"></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="history" className="mt-0">
              <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800">
                <CardContent className="p-4">
                  <div className="space-y-1">
                    <div className="p-3 bg-zinc-800/50 rounded-lg flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="w-7 h-7 rounded-full bg-zinc-700 flex items-center justify-center mr-2">
                          <span className="material-icons text-[#2DF2C4] text-sm">currency_bitcoin</span>
                        </div>
                        <div>
                          <div className="font-medium">BTC/USDT</div>
                          <div className="text-xs text-gray-400">Buy • 0.05 BTC</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-[#2DF2C4]">+$145.20</div>
                        <div className="text-xs text-gray-400">2 hours ago</div>
                      </div>
                    </div>
                    
                    <div className="p-3 bg-zinc-800/50 rounded-lg flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="w-7 h-7 rounded-full bg-zinc-700 flex items-center justify-center mr-2">
                          <span className="material-icons text-[#2DF2C4] text-sm">toll</span>
                        </div>
                        <div>
                          <div className="font-medium">ETH/USDT</div>
                          <div className="text-xs text-gray-400">Sell • 1.2 ETH</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-[#FF2D9A]">-$78.35</div>
                        <div className="text-xs text-gray-400">1 day ago</div>
                      </div>
                    </div>
                    
                    <div className="p-3 bg-zinc-800/50 rounded-lg flex items-center justify-between">
                      <div className="flex items-center">
                        <div className="w-7 h-7 rounded-full bg-zinc-700 flex items-center justify-center mr-2">
                          <span className="material-icons text-[#2DF2C4] text-sm">school</span>
                        </div>
                        <div>
                          <div className="font-medium">Course Completed</div>
                          <div className="text-xs text-gray-400">Trading Fundamentals</div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-xs text-gray-400">3 days ago</div>
                      </div>
                    </div>
                  </div>
                  
                  <Button className="w-full mt-4 bg-zinc-800 hover:bg-zinc-700 text-gray-300">
                    Show More
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </section>
        
        <section>
          <h2 className="text-xl font-semibold mb-4">Settings</h2>
          
          <div className="space-y-4">
            <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800">
              <CardContent className="p-4">
                <h3 className="font-medium mb-3 flex items-center">
                  <span className="material-icons text-[#2DF2C4] mr-2">security</span>
                  Security
                </h3>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="text-sm">Change Password</div>
                    <Button variant="ghost" size="sm">
                      <span className="material-icons text-sm">chevron_right</span>
                    </Button>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="text-sm">Two-Factor Authentication</div>
                    <Button variant="ghost" size="sm">
                      <span className="material-icons text-sm">chevron_right</span>
                    </Button>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="text-sm">API Keys</div>
                    <Button variant="ghost" size="sm">
                      <span className="material-icons text-sm">chevron_right</span>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800">
              <CardContent className="p-4">
                <h3 className="font-medium mb-3 flex items-center">
                  <span className="material-icons text-[#FF2D9A] mr-2">notifications</span>
                  Notifications
                </h3>
                
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="text-sm">Price Alerts</div>
                    <Button variant="ghost" size="sm">
                      <span className="material-icons text-sm">chevron_right</span>
                    </Button>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="text-sm">News Updates</div>
                    <Button variant="ghost" size="sm">
                      <span className="material-icons text-sm">chevron_right</span>
                    </Button>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="text-sm">Email Notifications</div>
                    <Button variant="ghost" size="sm">
                      <span className="material-icons text-sm">chevron_right</span>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>
      </main>
      <BottomNavigation />
    </div>
  );
}
