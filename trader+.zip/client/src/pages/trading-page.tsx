import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import Header from "@/components/layout/Header";
import BottomNavigation from "@/components/layout/BottomNavigation";
import TradingChart from "@/components/dashboard/TradingChart";

export default function TradingPage() {
  const [orderType, setOrderType] = useState("market");
  // В демо-режиме показываем одну активную позицию
  const [activePosition, setActivePosition] = useState(true);
  
  return (
    <div className="min-h-screen bg-black bg-[radial-gradient(circle_at_25%_25%,rgba(45,242,196,0.05)_0%,transparent_50%),radial-gradient(circle_at_75%_75%,rgba(255,45,154,0.05)_0%,transparent_50%)]">
      <Header />
      <main className="pt-20 pb-16 px-4">
        <section className="mb-6">
          <div className="flex justify-between items-center mb-4">
            <div className="flex items-center">
              <div className="h-8 w-8 rounded-full bg-zinc-800 flex items-center justify-center mr-2">
                <span className="material-icons text-[#2DF2C4] text-sm">currency_bitcoin</span>
              </div>
              <div>
                <h2 className="font-semibold">BTC/USDT</h2>
                <div className="flex items-center">
                  <span className="text-sm font-medium">$64,891.24</span>
                  <span className="text-xs text-[#2DF2C4] ml-2">+1.2%</span>
                </div>
              </div>
            </div>
            
            <div className="flex gap-2">
              <Select defaultValue="1h">
                <SelectTrigger className="w-20 h-8 bg-zinc-900 text-xs">
                  <SelectValue placeholder="Timeframe" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="1m">1m</SelectItem>
                  <SelectItem value="5m">5m</SelectItem>
                  <SelectItem value="15m">15m</SelectItem>
                  <SelectItem value="1h">1h</SelectItem>
                  <SelectItem value="4h">4h</SelectItem>
                  <SelectItem value="1d">1d</SelectItem>
                </SelectContent>
              </Select>
              
              <Button 
                variant="ghost" 
                size="icon"
                className="h-8 w-8 bg-zinc-900"
              >
                <span className="material-icons text-sm">map</span>
              </Button>
            </div>
          </div>
          
          <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800">
            <CardContent className="p-0">
              <div className="h-60 relative">
                <div className="absolute inset-0 bg-zinc-900/50">
                  <TradingChart onSettings={() => {}} />
                </div>
              </div>
            </CardContent>
          </Card>
        </section>
        
        <section className="mb-6">
          <Tabs defaultValue="spot" className="w-full">
            <TabsList className="grid grid-cols-3 bg-zinc-900/50 border border-gray-800 mb-4">
              <TabsTrigger value="spot">Spot</TabsTrigger>
              <TabsTrigger value="futures">Futures</TabsTrigger>
              <TabsTrigger value="options">Options</TabsTrigger>
            </TabsList>
            
            <TabsContent value="spot" className="mt-0">
              <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800">
                <CardContent className="p-4">
                  <div className="flex justify-between mb-4">
                    <Button 
                      variant={orderType === "market" ? "default" : "outline"}
                      className={orderType === "market" ? "bg-zinc-800 border border-[#2DF2C4]" : ""}
                      onClick={() => setOrderType("market")}
                    >
                      Market
                    </Button>
                    <Button 
                      variant={orderType === "limit" ? "default" : "outline"}
                      className={orderType === "limit" ? "bg-zinc-800 border border-[#2DF2C4]" : ""}
                      onClick={() => setOrderType("limit")}
                    >
                      Limit
                    </Button>
                    <Button 
                      variant={orderType === "stop" ? "default" : "outline"}
                      className={orderType === "stop" ? "bg-zinc-800 border border-[#2DF2C4]" : ""}
                      onClick={() => setOrderType("stop")}
                    >
                      Stop
                    </Button>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm text-gray-400 mb-1 block">
                        Price (USDT)
                      </label>
                      <Input 
                        type="text" 
                        placeholder="0.00" 
                        className="bg-zinc-800"
                        value={orderType === "market" ? "Market" : ""}
                        readOnly={orderType === "market"}
                      />
                    </div>
                    
                    <div>
                      <label className="text-sm text-gray-400 mb-1 block">
                        Amount (BTC)
                      </label>
                      <Input 
                        type="text" 
                        placeholder="0.00" 
                        className="bg-zinc-800"
                      />
                    </div>
                    
                    <div className="grid grid-cols-4 gap-2">
                      <Button 
                        variant="outline"
                        size="sm"
                        className="bg-zinc-800 text-xs"
                      >
                        25%
                      </Button>
                      <Button 
                        variant="outline"
                        size="sm"
                        className="bg-zinc-800 text-xs"
                      >
                        50%
                      </Button>
                      <Button 
                        variant="outline"
                        size="sm"
                        className="bg-zinc-800 text-xs"
                      >
                        75%
                      </Button>
                      <Button 
                        variant="outline"
                        size="sm"
                        className="bg-zinc-800 text-xs"
                      >
                        100%
                      </Button>
                    </div>
                    
                    <div className="flex gap-2">
                      <Button className="flex-1 bg-[#2DF2C4] hover:bg-[#2DF2C4]/80 text-black">
                        Buy
                      </Button>
                      <Button className="flex-1 bg-[#FF2D9A] hover:bg-[#FF2D9A]/80 text-white">
                        Sell
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="futures" className="mt-0">
              <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800">
                <CardContent className="p-4">
                  <div className="flex flex-col items-center justify-center py-4">
                    <div className="w-12 h-12 rounded-full bg-zinc-800 flex items-center justify-center mb-3">
                      <span className="material-icons text-gray-400">lock</span>
                    </div>
                    <h3 className="font-medium mb-1">Futures Trading</h3>
                    <p className="text-sm text-gray-400 text-center mb-4">
                      Complete your KYC verification to access futures trading
                    </p>
                    <Button 
                      className="border border-[#2DF2C4] bg-zinc-900/50 hover:bg-[#2DF2C4]/10 text-white"
                    >
                      <span className="material-icons text-sm mr-1">verified_user</span>
                      <span>Verify Identity</span>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="options" className="mt-0">
              <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800">
                <CardContent className="p-4">
                  <div className="flex flex-col items-center justify-center py-4">
                    <div className="w-12 h-12 rounded-full bg-zinc-800 flex items-center justify-center mb-3">
                      <span className="material-icons text-gray-400">schedule</span>
                    </div>
                    <h3 className="font-medium mb-1">Coming Soon</h3>
                    <p className="text-sm text-gray-400 text-center mb-4">
                      Options trading will be available in the next update
                    </p>
                    <Button 
                      className="border border-[#2DF2C4] bg-zinc-900/50 hover:bg-[#2DF2C4]/10 text-white"
                    >
                      <span className="material-icons text-sm mr-1">notifications</span>
                      <span>Get Notified</span>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </section>
        
        <section>
          <h2 className="text-xl font-semibold mb-4">Positions</h2>
          <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800">
            <CardContent className="p-4">
              {activePosition ? (
                <div className="p-3 bg-zinc-800/70 rounded-lg">
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center">
                      <div className="h-6 w-6 rounded-full bg-zinc-700 flex items-center justify-center mr-2">
                        <span className="material-icons text-[#2DF2C4] text-xs">currency_bitcoin</span>
                      </div>
                      <span className="font-medium">BTC/USDT</span>
                    </div>
                    <div className="px-2 py-0.5 rounded bg-[#2DF2C4]/20 text-[#2DF2C4] text-xs">
                      Long
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2 mb-3">
                    <div>
                      <div className="text-xs text-gray-400">Entry Price</div>
                      <div className="text-sm">$63,450.25</div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-400">Mark Price</div>
                      <div className="text-sm">$64,891.24</div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-400">PnL</div>
                      <div className="text-sm text-[#2DF2C4]">+$248.36 (2.2%)</div>
                    </div>
                    <div>
                      <div className="text-xs text-gray-400">Size</div>
                      <div className="text-sm">0.15 BTC</div>
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button 
                      variant="outline"
                      size="sm"
                      className="text-xs flex-1"
                    >
                      <span className="material-icons text-xs mr-1">edit</span>
                      Edit
                    </Button>
                    <Button 
                      variant="destructive"
                      size="sm"
                      className="text-xs flex-1"
                    >
                      <span className="material-icons text-xs mr-1">close</span>
                      Close
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-6">
                  <div className="w-12 h-12 rounded-full bg-zinc-800 flex items-center justify-center mb-3">
                    <span className="material-icons text-gray-400">candlestick_chart</span>
                  </div>
                  <h3 className="font-medium mb-1">No Open Positions</h3>
                  <p className="text-sm text-gray-400 text-center mb-4">
                    Start trading to see your positions here
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </section>
      </main>
      <BottomNavigation />
    </div>
  );
}
