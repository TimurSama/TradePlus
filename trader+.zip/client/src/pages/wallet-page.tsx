import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Header from "@/components/layout/Header";
import BottomNavigation from "@/components/layout/BottomNavigation";

interface Wallet {
  id: number;
  name: string;
  type: string;
  balance: string;
  change: string;
  isPositive: boolean;
  icon: string;
}

export default function WalletPage() {
  const [wallets, setWallets] = useState<Wallet[]>([
    {
      id: 1,
      name: "Bitcoin",
      type: "BTC",
      balance: "0.0045 BTC",
      change: "$245.67",
      isPositive: true,
      icon: "currency_bitcoin"
    },
    {
      id: 2,
      name: "Ethereum",
      type: "ETH",
      balance: "0.38 ETH",
      change: "$1,324.56",
      isPositive: false,
      icon: "toll"
    },
    {
      id: 3,
      name: "USD Tether",
      type: "USDT",
      balance: "1,250 USDT",
      change: "$1,250.00",
      isPositive: true,
      icon: "attach_money"
    }
  ]);
  
  const [connectedServices, setConnectedServices] = useState([
    {
      id: 1,
      name: "Binance",
      status: "Connected",
      icon: "B"
    },
    {
      id: 2,
      name: "Metamask",
      status: "Connected",
      icon: "M"
    }
  ]);
  
  return (
    <div className="min-h-screen bg-black bg-[radial-gradient(circle_at_25%_25%,rgba(45,242,196,0.05)_0%,transparent_50%),radial-gradient(circle_at_75%_75%,rgba(255,45,154,0.05)_0%,transparent_50%)]">
      <Header />
      <main className="pt-20 pb-16 px-4">
        <section className="mb-8">
          <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800 rounded-2xl">
            <CardContent className="p-5">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-semibold">Wallet</h2>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="border-[#2DF2C4] text-[#2DF2C4] hover:bg-[#2DF2C4]/10"
                >
                  <span className="material-icons text-sm mr-1">add</span>
                  <span>Add Asset</span>
                </Button>
              </div>
              
              <div className="mb-4">
                <div className="text-sm text-gray-400 mb-1">Total Balance</div>
                <div className="text-2xl font-bold">$2,820.23</div>
                <div className="flex items-center text-sm text-[#2DF2C4]">
                  <span className="material-icons text-sm mr-1">arrow_upward</span>
                  <span>+$124.45 (4.6%)</span>
                </div>
              </div>
              
              <div className="flex gap-3">
                <Button 
                  className="flex-1 border border-[#2DF2C4] bg-zinc-900/50 hover:bg-[#2DF2C4]/10 text-white"
                >
                  <span className="material-icons text-sm mr-1">arrow_downward</span>
                  <span>Deposit</span>
                </Button>
                <Button 
                  className="flex-1 border border-[#FF2D9A] bg-zinc-900/50 hover:bg-[#FF2D9A]/10 text-white"
                >
                  <span className="material-icons text-sm mr-1">arrow_upward</span>
                  <span>Withdraw</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </section>
        
        <section className="mb-8">
          <Tabs defaultValue="crypto" className="w-full">
            <TabsList className="grid grid-cols-3 bg-zinc-900/50 border border-gray-800 mb-4">
              <TabsTrigger value="crypto">Crypto</TabsTrigger>
              <TabsTrigger value="fiat">Fiat</TabsTrigger>
              <TabsTrigger value="staking">Staking</TabsTrigger>
            </TabsList>
            
            <TabsContent value="crypto" className="mt-0">
              <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800">
                <CardContent className="p-0">
                  {wallets.map((wallet) => (
                    <div 
                      key={wallet.id} 
                      className="p-4 border-b last:border-b-0 border-gray-800 flex items-center hover:bg-zinc-800/20 transition-colors cursor-pointer"
                    >
                      <div className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center mr-3">
                        <span className="material-icons text-[#2DF2C4]">
                          {wallet.icon}
                        </span>
                      </div>
                      <div className="flex-1">
                        <div className="flex justify-between">
                          <div className="font-medium">{wallet.name}</div>
                          <div className="font-medium">{wallet.balance}</div>
                        </div>
                        <div className="flex justify-between text-sm">
                          <div className="text-gray-400">{wallet.type}</div>
                          <div className={wallet.isPositive ? "text-[#2DF2C4]" : "text-[#FF2D9A]"}>
                            {wallet.isPositive ? "+" : ""}{wallet.change}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="fiat" className="mt-0">
              <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800">
                <CardContent className="p-4">
                  <div className="flex flex-col items-center justify-center py-8">
                    <div className="w-12 h-12 rounded-full bg-zinc-800 flex items-center justify-center mb-3">
                      <span className="material-icons text-gray-400">account_balance</span>
                    </div>
                    <h3 className="font-medium text-lg mb-1">No Fiat Accounts</h3>
                    <p className="text-sm text-gray-400 text-center mb-4">
                      Connect a bank account or card to deposit and withdraw fiat currency
                    </p>
                    <Button 
                      className="border border-[#2DF2C4] bg-zinc-900/50 hover:bg-[#2DF2C4]/10 text-white"
                    >
                      <span className="material-icons text-sm mr-1">add_circle</span>
                      <span>Add Bank Account</span>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="staking" className="mt-0">
              <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800">
                <CardContent className="p-4">
                  <div className="flex flex-col items-center justify-center py-8">
                    <div className="w-12 h-12 rounded-full bg-zinc-800 flex items-center justify-center mb-3">
                      <span className="material-icons text-gray-400">savings</span>
                    </div>
                    <h3 className="font-medium text-lg mb-1">No Staking Assets</h3>
                    <p className="text-sm text-gray-400 text-center mb-4">
                      Earn passive income by staking your cryptocurrency assets
                    </p>
                    <Button 
                      className="border border-[#2DF2C4] bg-zinc-900/50 hover:bg-[#2DF2C4]/10 text-white"
                    >
                      <span className="material-icons text-sm mr-1">add_circle</span>
                      <span>Start Staking</span>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </section>
        
        <section>
          <h2 className="text-xl font-semibold mb-4">Connected Services</h2>
          <Card className="bg-zinc-900/50 backdrop-blur-md border-gray-800">
            <CardContent className="p-0">
              {connectedServices.map((service) => (
                <div 
                  key={service.id} 
                  className="p-4 border-b last:border-b-0 border-gray-800 flex items-center justify-between"
                >
                  <div className="flex items-center">
                    <div className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center mr-3 text-[#2DF2C4] font-bold">
                      {service.icon}
                    </div>
                    <div>
                      <div className="font-medium">{service.name}</div>
                      <div className="text-sm text-[#2DF2C4]">{service.status}</div>
                    </div>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    className="text-gray-400"
                  >
                    <span className="material-icons">more_vert</span>
                  </Button>
                </div>
              ))}
              
              <div className="p-4">
                <Button 
                  className="w-full border border-[#2DF2C4] bg-zinc-900/50 hover:bg-[#2DF2C4]/10 text-white"
                >
                  <span className="material-icons text-sm mr-1">add_circle</span>
                  <span>Connect New Service</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </section>
      </main>
      <BottomNavigation />
    </div>
  );
}
