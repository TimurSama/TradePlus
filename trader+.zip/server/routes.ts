import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication routes
  setupAuth(app);

  // API routes
  app.get("/api/markets", (req, res) => {
    // Sample market data
    const markets = [
      { symbol: "BTC/USDT", price: 64891.24, change: 1.2 },
      { symbol: "ETH/USDT", price: 3487.12, change: 0.8 },
      { symbol: "SOL/USDT", price: 129.87, change: -2.1 },
      { symbol: "XRP/USDT", price: 0.5621, change: 1.5 },
      { symbol: "ADA/USDT", price: 0.4521, change: -0.5 },
    ];
    
    res.json(markets);
  });

  app.get("/api/news", (req, res) => {
    // Sample news data
    const news = [
      {
        id: 1,
        title: "Bitcoin breaks $65K resistance",
        summary: "BTC surges past key resistance level as institutional investors increase holdings.",
        source: "CryptoDaily",
        time: "10m ago"
      },
      {
        id: 2,
        title: "Fed meeting impact on markets",
        summary: "Markets respond to Federal Reserve's latest interest rate decision and forward guidance.",
        source: "FinanceNews",
        time: "25m ago"
      },
      {
        id: 3,
        title: "ETH 2.0 update rollout",
        summary: "Ethereum completes another milestone toward full ETH 2.0 implementation.",
        source: "BlockchainReporter",
        time: "45m ago"
      },
      {
        id: 4,
        title: "New regulations impact crypto",
        summary: "Regulatory changes in EU and Asia affect market sentiment and trading volumes.",
        source: "RegulationWatch",
        time: "1h ago"
      }
    ];
    
    res.json(news);
  });

  const httpServer = createServer(app);

  return httpServer;
}
